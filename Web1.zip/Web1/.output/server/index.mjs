globalThis.__nitro_main__ = import.meta.url;
import { n as HTTPError, r as defineLazyEventHandler, t as H3Core } from "./_libs/h3+rou3+srvx.mjs";
import { t as HookableCore } from "./_libs/hookable.mjs";
import { r as FastResponse } from "./_libs/h3-v2+rou3+srvx.mjs";
//#region #nitro-vite-setup
function lazyService(loader) {
	let promise, mod;
	return { fetch(req) {
		if (mod) return mod.fetch(req);
		if (!promise) promise = loader().then((_mod) => mod = _mod.default || _mod);
		return promise.then((mod) => mod.fetch(req));
	} };
}
var services = { ["ssr"]: lazyService(() => import("./_ssr/ssr.mjs")) };
globalThis.__nitro_vite_envs__ = services;
//#endregion
//#region #nitro/virtual/public-assets-data
var public_assets_data_default = {
	"/favicon.ico": {
		"type": "image/vnd.microsoft.icon",
		"etag": "\"4f95-3RXc3p2mhEAs1WBwaIvE0Y0uu0Y\"",
		"mtime": "2026-08-12T19:41:53.963Z",
		"size": 20373,
		"path": "../public/favicon.ico"
	},
	"/favicon.svg": {
		"type": "image/svg+xml",
		"etag": "\"650-jQWS7gpoas8GBSIMJuP7FseucHY\"",
		"mtime": "2026-08-17T07:32:37.214Z",
		"size": 1616,
		"path": "../public/favicon.svg"
	},
	"/robots.txt": {
		"type": "text/plain; charset=utf-8",
		"etag": "\"a0-CKGXSIe7TSsqDTmGm/nY1t/o5d0\"",
		"mtime": "2026-08-12T19:41:53.981Z",
		"size": 160,
		"path": "../public/robots.txt"
	},
	"/site.webmanifest": {
		"type": "application/manifest+json",
		"etag": "\"133-CZH9+ebp5Wt6AuLAlqTcDcZStZg\"",
		"mtime": "2026-08-17T07:32:37.216Z",
		"size": 307,
		"path": "../public/site.webmanifest"
	},
	"/assets/alerts-C6FAXTzq.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"c95-htF2jWxogHIVs1bkug8jWbA3mFs\"",
		"mtime": "2026-08-17T07:33:25.943Z",
		"size": 3221,
		"path": "../public/assets/alerts-C6FAXTzq.js"
	},
	"/assets/AreaChart-DRHbNxhX.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2aba-RUedgEtuRpn6hTCBC+g9CClrqqw\"",
		"mtime": "2026-08-17T07:33:25.943Z",
		"size": 10938,
		"path": "../public/assets/AreaChart-DRHbNxhX.js"
	},
	"/assets/costs-SVG0lHsh.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"14c0-6ExKQrSN8pnh9VThJNi/7FnFdD4\"",
		"mtime": "2026-08-17T07:33:25.943Z",
		"size": 5312,
		"path": "../public/assets/costs-SVG0lHsh.js"
	},
	"/assets/BarChart-D2TyB_Xu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"20d-hv9gHAuoA/MZpoi9QSZv086t4Q0\"",
		"mtime": "2026-08-17T07:33:25.943Z",
		"size": 525,
		"path": "../public/assets/BarChart-D2TyB_Xu.js"
	},
	"/assets/dashboard-data-DBJMUTN1.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"bc16-BriiuWhZStM+5aM56x3w9eDQqig\"",
		"mtime": "2026-08-17T07:33:25.948Z",
		"size": 48150,
		"path": "../public/assets/dashboard-data-DBJMUTN1.js"
	},
	"/assets/devices-C4UTfNMn.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"1b54-fL95qFvKOb6ATUpgTGUY77Ft2hs\"",
		"mtime": "2026-08-17T07:33:25.948Z",
		"size": 6996,
		"path": "../public/assets/devices-C4UTfNMn.js"
	},
	"/assets/energy-8mOQI0ir.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"36eb-1VRQc4PLGzadTl7b5+NMPIDZMnI\"",
		"mtime": "2026-08-17T07:33:25.948Z",
		"size": 14059,
		"path": "../public/assets/energy-8mOQI0ir.js"
	},
	"/assets/exports-BfDTSqVI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"ca3-4ih7uHsoiFw/V6FzEeNszm4pUmM\"",
		"mtime": "2026-08-17T07:33:25.950Z",
		"size": 3235,
		"path": "../public/assets/exports-BfDTSqVI.js"
	},
	"/assets/info-BtgcWNsg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"147-u4yQdHi5o73NRpSmextXGbz3bDk\"",
		"mtime": "2026-08-17T07:33:25.950Z",
		"size": 327,
		"path": "../public/assets/info-BtgcWNsg.js"
	},
	"/assets/Line--BlnA-oc.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2a35-ANtMphKmcFlEHQy5aIL+2wQ7tDQ\"",
		"mtime": "2026-08-17T07:33:25.943Z",
		"size": 10805,
		"path": "../public/assets/Line--BlnA-oc.js"
	},
	"/assets/routes-B_9Bx4Fg.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"2500-+6fNsKEz8oJibmMM4Hi6HUBzju8\"",
		"mtime": "2026-08-17T07:33:25.951Z",
		"size": 9472,
		"path": "../public/assets/routes-B_9Bx4Fg.js"
	},
	"/assets/reliability-ByQjJShu.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"191f-FtRPAe/+yDPtnEMbzwANYjzCOGM\"",
		"mtime": "2026-08-17T07:33:25.950Z",
		"size": 6431,
		"path": "../public/assets/reliability-ByQjJShu.js"
	},
	"/assets/settings-CJZhZ9ZF.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"f15-pTWBqBuKUFqpwggpNfIMrn0YHoQ\"",
		"mtime": "2026-08-17T07:33:25.951Z",
		"size": 3861,
		"path": "../public/assets/settings-CJZhZ9ZF.js"
	},
	"/assets/styles-BaR8hv1o.css": {
		"type": "text/css; charset=utf-8",
		"etag": "\"13e65-gT/RP6RU3hCLtGTm0vGDj4867qs\"",
		"mtime": "2026-08-17T07:33:25.955Z",
		"size": 81509,
		"path": "../public/assets/styles-BaR8hv1o.css"
	},
	"/assets/sustainability-BkHBEW63.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"936f-bmFmfNR0LQfDPUnbM5gHTh85jZU\"",
		"mtime": "2026-08-17T07:33:25.952Z",
		"size": 37743,
		"path": "../public/assets/sustainability-BkHBEW63.js"
	},
	"/assets/switch-CRxCYTDI.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"3006-FtyA5SxK0CCtjdZR+rihIYZ5iAU\"",
		"mtime": "2026-08-17T07:33:25.952Z",
		"size": 12294,
		"path": "../public/assets/switch-CRxCYTDI.js"
	},
	"/assets/zap-Dbw4zGLM.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"17f-9VBD0ve39JtPs9pg9IBEyF/UigY\"",
		"mtime": "2026-08-17T07:33:25.954Z",
		"size": 383,
		"path": "../public/assets/zap-Dbw4zGLM.js"
	},
	"/assets/trending-down-fAw7YiQf.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"b0-MIFjS2Z8GCBUGki2GN0lU7svNaE\"",
		"mtime": "2026-08-17T07:33:25.954Z",
		"size": 176,
		"path": "../public/assets/trending-down-fAw7YiQf.js"
	},
	"/assets/StatCard-Dr3jHWQz.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"5a9c3-BQiiRB9fqh4Arc432LozYOXPqO4\"",
		"mtime": "2026-08-17T07:33:25.943Z",
		"size": 371139,
		"path": "../public/assets/StatCard-Dr3jHWQz.js"
	},
	"/assets/index-C4sTDVkC.js": {
		"type": "text/javascript; charset=utf-8",
		"etag": "\"a83e0-qOChRcvQYTWbGHDjIGEZjUKNeZQ\"",
		"mtime": "2026-08-17T07:33:25.943Z",
		"size": 689120,
		"path": "../public/assets/index-C4sTDVkC.js"
	}
};
//#endregion
//#region #nitro/virtual/public-assets
var publicAssetBases = {};
function isPublicAssetURL(id = "") {
	if (public_assets_data_default[id]) return true;
	for (const base in publicAssetBases) if (id.startsWith(base)) return true;
	return false;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/route-rules.mjs
var headers = ((m) => function headersRouteRule(event) {
	for (const [key, value] of Object.entries(m.options || {})) event.res.headers.set(key, value);
});
//#endregion
//#region #nitro/virtual/routing
var findRouteRules = /* @__PURE__ */ (() => {
	const $0 = [{
		name: "headers",
		route: "/assets/**",
		handler: headers,
		options: { "cache-control": "public, max-age=31536000, immutable" }
	}];
	return (m, p) => {
		let r = [];
		if (p.charCodeAt(p.length - 1) === 47) p = p.slice(0, -1) || "/";
		let s = p.split("/");
		if (s.length > 1) {
			if (s[1] === "assets") r.unshift({
				data: $0,
				params: { "_": s.slice(2).join("/") }
			});
		}
		return r;
	};
})();
var _lazy_uiXQf2 = defineLazyEventHandler(() => import("./_chunks/ssr-renderer.mjs"));
var findRoute = /* @__PURE__ */ (() => {
	const data = {
		route: "/**",
		handler: _lazy_uiXQf2
	};
	return ((_m, p) => {
		return {
			data,
			params: { "_": p.slice(1) }
		};
	});
})();
[].filter(Boolean);
//#endregion
//#region node_modules/nitro/dist/runtime/internal/error/prod.mjs
var errorHandler = (error, event) => {
	const res = defaultHandler(error, event);
	return new FastResponse(typeof res.body === "string" ? res.body : JSON.stringify(res.body, null, 2), res);
};
function defaultHandler(error, event) {
	const unhandled = error.unhandled ?? !HTTPError.isError(error);
	const { status = 500, statusText = "" } = unhandled ? {} : error;
	if (status === 404) {
		const url = event.url || new URL(event.req.url);
		const baseURL = "/";
		if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) return {
			status: 302,
			headers: new Headers({ location: `${baseURL}${url.pathname.slice(1)}${url.search}` })
		};
	}
	const headers = new Headers(unhandled ? {} : error.headers);
	headers.set("content-type", "application/json; charset=utf-8");
	return {
		status,
		statusText,
		headers,
		body: {
			error: true,
			...unhandled ? {
				status,
				unhandled: true
			} : typeof error.toJSON === "function" ? error.toJSON() : {
				status,
				statusText,
				message: error.message
			}
		}
	};
}
//#endregion
//#region #nitro/virtual/error-handler
var errorHandlers = [errorHandler];
async function error_handler_default(error, event) {
	for (const handler of errorHandlers) try {
		const response = await handler(error, event, { defaultHandler });
		if (response) return response;
	} catch (error) {
		console.error(error);
	}
}
//#endregion
//#region #nitro/virtual/app
function createNitroApp() {
	const captureError = (error, errorCtx) => {
		if (errorCtx?.event) {
			const errors = errorCtx.event.req.context?.nitro?.errors;
			if (errors) errors.push({
				error,
				context: errorCtx
			});
		}
	};
	const h3App = createH3App({ onError(error, event) {
		return error_handler_default(error, event);
	} });
	let appHandler = (req) => {
		req.context ||= {};
		req.context.nitro = req.context.nitro || { errors: [] };
		return h3App.fetch(req);
	};
	return {
		fetch: appHandler,
		h3: h3App,
		hooks: void 0,
		captureError
	};
}
function createH3App(config) {
	const h3App = new H3Core(config);
	h3App["~findRoute"] = (event) => findRoute(event.req.method, event.url.pathname);
	h3App["~getMiddleware"] = (event, route) => {
		const pathname = event.url.pathname;
		const method = event.req.method;
		const middleware = [];
		const routeRules = getRouteRules(method, pathname);
		event.context.routeRules = routeRules?.routeRules;
		if (routeRules?.routeRuleMiddleware.length) middleware.push(...routeRules.routeRuleMiddleware);
		if (route?.data?.middleware?.length) middleware.push(...route.data.middleware);
		return middleware;
	};
	return h3App;
}
//#endregion
//#region node_modules/nitro/dist/runtime/internal/app.mjs
var APP_ID = "default";
function useNitroApp() {
	let instance = useNitroApp._instance;
	if (instance) return instance;
	instance = useNitroApp._instance = createNitroApp();
	globalThis.__nitro__ = globalThis.__nitro__ || {};
	globalThis.__nitro__[APP_ID] = instance;
	return instance;
}
function useNitroHooks() {
	const nitroApp = useNitroApp();
	const hooks = nitroApp.hooks;
	if (hooks) return hooks;
	return nitroApp.hooks = new HookableCore();
}
function getRouteRules(method, pathname) {
	const m = findRouteRules(method, pathname);
	if (!m?.length) return { routeRuleMiddleware: [] };
	const routeRules = {};
	for (const layer of m) for (const rule of layer.data) {
		const currentRule = routeRules[rule.name];
		if (currentRule) {
			if (rule.options === false) {
				delete routeRules[rule.name];
				continue;
			}
			if (typeof currentRule.options === "object" && typeof rule.options === "object") currentRule.options = {
				...currentRule.options,
				...rule.options
			};
			else currentRule.options = rule.options;
			currentRule.route = rule.route;
			currentRule.params = {
				...currentRule.params,
				...layer.params
			};
		} else if (rule.options !== false) routeRules[rule.name] = {
			...rule,
			params: layer.params
		};
	}
	const middleware = [];
	const orderedRules = Object.values(routeRules).sort((a, b) => (a.handler?.order || 0) - (b.handler?.order || 0));
	for (const rule of orderedRules) {
		if (rule.options === false || !rule.handler) continue;
		middleware.push(rule.handler(rule));
	}
	return {
		routeRules,
		routeRuleMiddleware: middleware
	};
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/_module-handler.mjs
function createHandler(hooks) {
	const nitroApp = useNitroApp();
	const nitroHooks = useNitroHooks();
	return {
		async fetch(request, env, context) {
			globalThis.__env__ = env;
			augmentReq(request, {
				env,
				context
			});
			const ctxExt = {};
			const url = new URL(request.url);
			if (hooks.fetch) {
				const res = await hooks.fetch(request, env, context, url, ctxExt);
				if (res) return res;
			}
			return await nitroApp.fetch(request);
		},
		scheduled(controller, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:scheduled", {
				controller,
				env,
				context
			}) || Promise.resolve());
		},
		email(message, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:email", {
				message,
				event: message,
				env,
				context
			}) || Promise.resolve());
		},
		queue(batch, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:queue", {
				batch,
				event: batch,
				env,
				context
			}) || Promise.resolve());
		},
		tail(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:tail", {
				traces,
				env,
				context
			}) || Promise.resolve());
		},
		trace(traces, env, context) {
			globalThis.__env__ = env;
			context.waitUntil(nitroHooks.callHook("cloudflare:trace", {
				traces,
				env,
				context
			}) || Promise.resolve());
		}
	};
}
function augmentReq(cfReq, ctx) {
	const req = cfReq;
	req.ip = cfReq.headers.get("cf-connecting-ip") || void 0;
	req.runtime ??= { name: "cloudflare" };
	req.runtime.cloudflare = {
		...req.runtime.cloudflare,
		...ctx
	};
	req.waitUntil = ctx.context?.waitUntil.bind(ctx.context);
}
//#endregion
//#region node_modules/nitro/dist/presets/cloudflare/runtime/cloudflare-module.mjs
var cloudflare_module_default = createHandler({ fetch(cfRequest, env, context, url) {
	if (env.ASSETS && isPublicAssetURL(url.pathname)) return env.ASSETS.fetch(cfRequest);
} });
//#endregion
export { cloudflare_module_default as default };
