//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BkaDwj3h.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/__root.tsx",
		children: [
			"/",
			"/alerts",
			"/costs",
			"/devices",
			"/energy",
			"/exports",
			"/reliability",
			"/settings",
			"/sustainability"
		],
		preloads: ["/assets/index-C4sTDVkC.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C4sTDVkC.js"
		} }]
	},
	"/": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B_9Bx4Fg.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/StatCard-Dr3jHWQz.js",
			"/assets/zap-Dbw4zGLM.js",
			"/assets/AreaChart-DRHbNxhX.js"
		]
	},
	"/alerts": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/alerts.tsx",
		children: void 0,
		preloads: [
			"/assets/alerts-C6FAXTzq.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/info-BtgcWNsg.js"
		]
	},
	"/costs": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/costs.tsx",
		children: void 0,
		preloads: [
			"/assets/costs-SVG0lHsh.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/StatCard-Dr3jHWQz.js",
			"/assets/trending-down-fAw7YiQf.js",
			"/assets/Line--BlnA-oc.js",
			"/assets/AreaChart-DRHbNxhX.js"
		]
	},
	"/devices": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/devices.tsx",
		children: void 0,
		preloads: [
			"/assets/devices-C4UTfNMn.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/switch-CRxCYTDI.js"
		]
	},
	"/energy": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/energy.tsx",
		children: void 0,
		preloads: [
			"/assets/energy-8mOQI0ir.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/StatCard-Dr3jHWQz.js",
			"/assets/zap-Dbw4zGLM.js",
			"/assets/BarChart-D2TyB_Xu.js",
			"/assets/Line--BlnA-oc.js"
		]
	},
	"/exports": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/exports.tsx",
		children: void 0,
		preloads: ["/assets/exports-BfDTSqVI.js", "/assets/dashboard-data-DBJMUTN1.js"]
	},
	"/reliability": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/reliability.tsx",
		children: void 0,
		preloads: [
			"/assets/reliability-ByQjJShu.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/StatCard-Dr3jHWQz.js",
			"/assets/info-BtgcWNsg.js",
			"/assets/BarChart-D2TyB_Xu.js"
		]
	},
	"/settings": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CJZhZ9ZF.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/switch-CRxCYTDI.js"
		]
	},
	"/sustainability": {
		filePath: "C:/Users/fivia/Documents/GitHub/electricity/Web1/src/routes/sustainability.tsx",
		children: void 0,
		preloads: [
			"/assets/sustainability-BkHBEW63.js",
			"/assets/dashboard-data-DBJMUTN1.js",
			"/assets/StatCard-Dr3jHWQz.js",
			"/assets/trending-down-fAw7YiQf.js",
			"/assets/AreaChart-DRHbNxhX.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
