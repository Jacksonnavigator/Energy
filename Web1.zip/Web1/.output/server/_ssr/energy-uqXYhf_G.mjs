import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { F as ArrowDown, N as ArrowUp, c as Timer, t as Zap, w as Gauge, x as Leaf } from "../_libs/lucide-react.mjs";
import { n as cn, r as useHydranetDashboardData, t as AppShell } from "./dashboard-data-10Pg--aE.mjs";
import { t as StatCard } from "./StatCard-CNwaNILP.mjs";
import { a as YAxis, c as Line, f as Cell, h as Legend, i as LineChart, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, r as BarChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/energy-uqXYhf_G.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tooltipStyle = {
	background: "var(--popover)",
	border: "1px solid var(--border)",
	borderRadius: "0.75rem",
	fontSize: 12,
	color: "var(--popover-foreground)"
};
var periodColor = {
	peak: "var(--warning)",
	standard: "var(--chart-1)",
	offpeak: "var(--chart-3)"
};
function TimeOfUseExplorer() {
	const { hourlyProfile, touBands, currency } = useHydranetDashboardData();
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [sort, setSort] = (0, import_react.useState)({
		key: "hour",
		dir: "asc"
	});
	const rows = (0, import_react.useMemo)(() => {
		return [...hourlyProfile.filter((h) => filter === "all" || h.period === filter)].sort((a, b) => sort.dir === "asc" ? a[sort.key] - b[sort.key] : b[sort.key] - a[sort.key]);
	}, [filter, sort]);
	const bandTotals = touBands.map((b) => {
		const set = hourlyProfile.filter((h) => h.period === b.id);
		const kwh = set.reduce((s, h) => s + h.kwh, 0);
		const cost = set.reduce((s, h) => s + h.cost, 0);
		return {
			...b,
			kwh,
			cost,
			avg: set.length ? kwh / set.length : 0,
			share: kwh
		};
	});
	const totalKwh = bandTotals.reduce((s, b) => s + b.kwh, 0);
	const toggleSort = (key) => setSort((s) => ({
		key,
		dir: s.key === key && s.dir === "asc" ? "desc" : "asc"
	}));
	const SortButton = ({ k, label }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		onClick: () => toggleSort(k),
		className: cn("inline-flex items-center gap-1 text-left transition-colors hover:text-foreground", sort.key === k ? "text-foreground" : "text-muted-foreground"),
		children: [label, sort.key === k && (sort.dir === "asc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUp, { className: "h-3 w-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, { className: "h-3 w-3" }))]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "card-surface mt-6 overflow-hidden",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 border-b border-border px-5 py-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Consumption by time of day"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Choose a tariff band to compare peak, standard and off-peak usage · East Africa Time (UTC+3)"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "flex flex-wrap gap-1.5",
					children: [{
						id: "all",
						label: "All hours"
					}, ...touBands].map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => setFilter(b.id),
						className: cn("rounded-full border px-3 py-1.5 text-xs font-medium transition-colors", filter === b.id ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover:text-foreground"),
						children: b.label
					}, b.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-4 border-b border-border px-5 py-4 sm:grid-cols-3",
				children: bandTotals.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-xl bg-secondary/50 p-3.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "h-2 w-2 rounded-full",
									style: { background: periodColor[b.id] }
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs font-medium",
									children: b.label
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "ml-auto text-[11px] text-muted-foreground",
									children: b.window
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-lg font-semibold tabular-nums",
							children: [b.kwh.toLocaleString(), " kWh"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground tabular-nums",
							children: [
								Math.round(b.kwh / totalKwh * 100),
								"% of day · avg ",
								b.avg.toFixed(0),
								" kWh/h · ",
								currency(b.cost)
							]
						})
					]
				}, b.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "h-64 px-2 py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
					width: "100%",
					height: "100%",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
						data: [...rows].sort((a, b) => a.hour - b.hour),
						margin: {
							left: -18,
							right: 8,
							top: 8
						},
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
								stroke: "var(--border)",
								vertical: false
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
								dataKey: "t",
								tickLine: false,
								axisLine: false,
								interval: filter === "all" ? 2 : 0,
								tick: {
									fontSize: 11,
									fill: "var(--muted-foreground)"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
								tickLine: false,
								axisLine: false,
								tick: {
									fontSize: 11,
									fill: "var(--muted-foreground)"
								}
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
								cursor: { fill: "var(--secondary)" },
								contentStyle: tooltipStyle
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
								dataKey: "kwh",
								name: "kWh",
								radius: [
									6,
									6,
									0,
									0
								],
								children: rows.slice().sort((a, b) => a.hour - b.hour).map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: periodColor[h.period] }, h.hour))
							})
						]
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto border-t border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[520px] text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border bg-secondary/40 text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-2.5 text-left font-medium",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortButton, {
									k: "hour",
									label: "Hour"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-2.5 text-left font-medium text-muted-foreground",
								children: "Band"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-2.5 text-right font-medium",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortButton, {
									k: "kwh",
									label: "Energy (kWh)"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-5 py-2.5 text-right font-medium",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SortButton, {
									k: "cost",
									label: "Cost"
								})
							})
						]
					}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", {
						className: "divide-y divide-border",
						children: rows.map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "transition-colors hover:bg-secondary/40",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-2.5 font-medium tabular-nums",
									children: h.t
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-2.5",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11px] font-medium",
										style: {
											background: `color-mix(in oklab, ${periodColor[h.period]} 14%, transparent)`,
											color: periodColor[h.period]
										},
										children: touBands.find((b) => b.id === h.period)?.label
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-2.5 text-right tabular-nums",
									children: h.kwh
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "px-5 py-2.5 text-right tabular-nums",
									children: currency(h.cost)
								})
							]
						}, h.hour))
					})]
				})
			})
		]
	});
}
function EnergyPage() {
	const { consumptionSeries, hourlyProfile, siteBreakdown, devices, platformSettings, currency, tariffPerKwh, allTelemetry, GRID_EMISSION_FACTOR_KGCO2_PER_KWH } = useHydranetDashboardData();
	const [chartRange, setChartRange] = (0, import_react.useState)("hours");
	const chartData = (0, import_react.useMemo)(() => {
		if (!allTelemetry.length) return [{
			label: "No data",
			kwh: 0,
			cost: 0
		}];
		const kwhValue = (pointPower) => Math.max(0, pointPower / 1e3 * .25);
		const formatCost = (kwh) => Number((kwh * tariffPerKwh).toFixed(1));
		if (chartRange === "hours") {
			const latest = new Date(Math.max(...allTelemetry.map((point) => point.ts)));
			const start = new Date(latest);
			start.setHours(latest.getHours() - 23, 0, 0, 0);
			const buckets = /* @__PURE__ */ new Map();
			allTelemetry.forEach((point) => {
				const date = new Date(point.ts);
				const bucketKey = new Date(date.getFullYear(), date.getMonth(), date.getDate(), date.getHours()).getTime();
				buckets.set(bucketKey, (buckets.get(bucketKey) ?? 0) + point.power);
			});
			return Array.from({ length: 24 }, (_, index) => {
				const ts = new Date(start);
				ts.setHours(start.getHours() + index);
				const key = new Date(ts.getFullYear(), ts.getMonth(), ts.getDate(), ts.getHours()).getTime();
				const totalPower = buckets.get(key) ?? 0;
				const kwh = kwhValue(totalPower);
				return {
					label: ts.toLocaleTimeString("en-US", {
						hour: "2-digit",
						minute: "2-digit",
						hour12: false
					}),
					kwh: Number(kwh.toFixed(1)),
					cost: formatCost(kwh)
				};
			});
		}
		if (chartRange === "days") {
			const latest = new Date(Math.max(...allTelemetry.map((point) => point.ts)));
			const start = new Date(latest);
			start.setHours(0, 0, 0, 0);
			start.setDate(start.getDate() - 6);
			const buckets = /* @__PURE__ */ new Map();
			allTelemetry.forEach((point) => {
				const date = new Date(point.ts);
				const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
				buckets.set(key, (buckets.get(key) ?? 0) + point.power);
			});
			return Array.from({ length: 7 }, (_, index) => {
				const ts = new Date(start);
				ts.setDate(start.getDate() + index);
				const key = `${ts.getFullYear()}-${String(ts.getMonth() + 1).padStart(2, "0")}-${String(ts.getDate()).padStart(2, "0")}`;
				const totalPower = buckets.get(key) ?? 0;
				const kwh = kwhValue(totalPower);
				return {
					label: ts.toLocaleDateString("en-US", {
						month: "short",
						day: "numeric"
					}),
					kwh: Number(kwh.toFixed(1)),
					cost: formatCost(kwh)
				};
			});
		}
		if (chartRange === "weeks") {
			const latest = new Date(Math.max(...allTelemetry.map((point) => point.ts)));
			const start = new Date(latest);
			const diff = (start.getDay() + 6) % 7;
			start.setDate(start.getDate() - diff);
			start.setHours(0, 0, 0, 0);
			start.setDate(start.getDate() - 35);
			const buckets = /* @__PURE__ */ new Map();
			allTelemetry.forEach((point) => {
				const date = new Date(point.ts);
				const monday = new Date(date);
				const mondayDiff = (monday.getDay() + 6) % 7;
				monday.setDate(monday.getDate() - mondayDiff);
				monday.setHours(0, 0, 0, 0);
				const key = `${monday.getFullYear()}-${String(monday.getMonth() + 1).padStart(2, "0")}-${String(monday.getDate()).padStart(2, "0")}`;
				buckets.set(key, (buckets.get(key) ?? 0) + point.power);
			});
			return Array.from({ length: 6 }, (_, index) => {
				const ts = new Date(start);
				ts.setDate(start.getDate() + index * 7);
				const key = `${ts.getFullYear()}-${String(ts.getMonth() + 1).padStart(2, "0")}-${String(ts.getDate()).padStart(2, "0")}`;
				const totalPower = buckets.get(key) ?? 0;
				const kwh = kwhValue(totalPower);
				return {
					label: ts.toLocaleDateString("en-US", {
						month: "short",
						day: "numeric"
					}),
					kwh: Number(kwh.toFixed(1)),
					cost: formatCost(kwh)
				};
			});
		}
		const bucketMap = /* @__PURE__ */ new Map();
		allTelemetry.forEach((point) => {
			const date = new Date(point.ts);
			const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
			bucketMap.set(key, (bucketMap.get(key) ?? 0) + point.power);
		});
		return Array.from({ length: 6 }, (_, index) => {
			const d = /* @__PURE__ */ new Date();
			d.setMonth(d.getMonth() - (5 - index));
			d.setDate(1);
			d.setHours(0, 0, 0, 0);
			const key = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
			const kwh = kwhValue(bucketMap.get(key) ?? 0);
			return {
				label: d.toLocaleDateString("en-US", {
					month: "short",
					year: "numeric"
				}),
				kwh: Number(kwh.toFixed(1)),
				cost: formatCost(kwh)
			};
		});
	}, [
		allTelemetry,
		chartRange,
		tariffPerKwh
	]);
	const monthToDateKwh = siteBreakdown.reduce((sum, site) => sum + site.kwh, 0);
	const peakDemand = devices.length ? Math.max(0, ...devices.map((device) => device.load)) : 0;
	const loadFactor = devices.length ? Math.min(1, devices.reduce((sum, device) => sum + device.load, 0) / Math.max(1, devices.length * 2.5)) : 0;
	const carbonIntensity = devices.length ? Math.round(GRID_EMISSION_FACTOR_KGCO2_PER_KWH * 1e3) : 0;
	const efficiencyNotes = (0, import_react.useMemo)(() => {
		if (!devices.length) return [];
		return devices.filter((device) => device.status !== "online").slice(0, 3).map((device) => ({
			title: device.status === "fault" ? "Power quality issue detected" : device.status === "stale" ? "Telemetry refresh overdue" : "Device connectivity issue",
			detail: device.status === "fault" ? `${device.name} is reporting a fault condition. Review current draw, relay state and protection thresholds.` : device.status === "stale" ? `${device.name} has stale telemetry. Refresh the latest reading before changing scheduling or demand plans.` : `${device.name} is offline. Confirm the gateway or network link before resuming normal control.`
		}));
	}, [devices]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Energy",
		subtitle: `Consumption analytics · ${platformSettings.timezone}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Month to date",
						value: monthToDateKwh.toLocaleString(),
						unit: "kWh",
						icon: Gauge,
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Peak demand",
						value: peakDemand.toFixed(1),
						unit: "kW",
						icon: Zap,
						tone: "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Load factor",
						value: loadFactor.toFixed(2),
						icon: Timer
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Carbon intensity",
						value: String(carbonIntensity),
						unit: "gCO₂/kWh",
						icon: Leaf
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-6 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Consumption vs cost"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Switch the chart to hours, days, weeks or months"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: [
							"hours",
							"days",
							"weeks",
							"months"
						].map((range) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setChartRange(range),
							className: cn("rounded-full border px-3 py-1.5 text-[11px] font-medium capitalize transition-colors", chartRange === range ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover:text-foreground"),
							children: range
						}, range))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-5 h-72",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
						width: "100%",
						height: "100%",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(LineChart, {
							data: chartData,
							margin: {
								left: -18,
								right: 4,
								top: 8
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
									stroke: "var(--border)",
									vertical: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
									dataKey: "label",
									tickLine: false,
									axisLine: false,
									tick: {
										fontSize: 11,
										fill: "var(--muted-foreground)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
									tickLine: false,
									axisLine: false,
									tick: {
										fontSize: 11,
										fill: "var(--muted-foreground)"
									}
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Legend, { wrapperStyle: { fontSize: 12 } }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "kwh",
									name: "kWh",
									stroke: "var(--chart-1)",
									strokeWidth: 2,
									dot: false
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
									type: "monotone",
									dataKey: "cost",
									name: "Cost (K)",
									stroke: "var(--chart-2)",
									strokeWidth: 2,
									dot: false
								})
							]
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TimeOfUseExplorer, {}),
			allTelemetry && allTelemetry.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-6 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold mb-4",
						children: "Detailed readings"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left py-2 px-3 font-medium text-muted-foreground",
										children: "Device"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left py-2 px-3 font-medium text-muted-foreground",
										children: "Date & Time"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-right py-2 px-3 font-medium text-muted-foreground",
										children: "Power (kW)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-right py-2 px-3 font-medium text-muted-foreground",
										children: "Energy (kWh)"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: allTelemetry.slice(0, 20).map((point) => {
								const date = new Date(point.ts);
								const dateStr = date.toLocaleDateString();
								const timeStr = date.toLocaleTimeString();
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50 hover:bg-secondary/30",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 px-3",
											children: point.deviceName || "Unknown"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-2 px-3 text-muted-foreground",
											children: [
												dateStr,
												" ",
												timeStr
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "text-right py-2 px-3",
											children: (point.power / 1e3).toFixed(2)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "text-right py-2 px-3",
											children: (point.power / 1e3 * .25).toFixed(3)
										})
									]
								}, point.id);
							}) })]
						})
					}),
					allTelemetry.length > 20 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: [
							"Showing 20 of ",
							allTelemetry.length,
							" readings. Load more to see earlier data."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Consumption by site"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: siteBreakdown,
								margin: {
									left: -18,
									right: 4,
									top: 8
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--border)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "site",
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 11,
											fill: "var(--muted-foreground)"
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 11,
											fill: "var(--muted-foreground)"
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										cursor: { fill: "var(--secondary)" },
										contentStyle: tooltipStyle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "kwh",
										name: "kWh",
										radius: [
											6,
											6,
											0,
											0
										],
										children: siteBreakdown.map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: i === 0 ? "var(--chart-1)" : "var(--chart-4)" }, i))
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Efficiency notes"
					}), efficiencyNotes.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-4 text-sm",
						children: efficiencyNotes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: note.title
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted-foreground",
							children: note.detail
						})] }, note.title))
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm text-muted-foreground",
						children: "No efficiency issues were detected from the live device data yet."
					})]
				})]
			})
		]
	});
}
//#endregion
export { EnergyPage as component };
