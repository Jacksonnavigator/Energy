import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { _ as useRouter, c as HeadContent, d as createRouter, f as Outlet, g as Link, h as createRootRouteWithContext, m as createFileRoute, p as lazyRouteComponent, s as Scripts } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getApp, o as getApps, s as initializeApp } from "../_libs/@firebase/app+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as QueryClientProvider } from "../_libs/tanstack__react-query.mjs";
import { a as signInWithEmailAndPassword, i as setPersistence, n as getAuth, o as signOut, r as onAuthStateChanged, t as browserLocalPersistence } from "../_libs/firebase__auth+tslib.mjs";
import "../_libs/firebase.mjs";
import { i as getFirestore } from "../_libs/@firebase/firestore+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-CWMaLdWN.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var styles_default = "/assets/styles-BaR8hv1o.css";
function reportLovableError(error, context = {}) {
	if (typeof window === "undefined") return;
	window.__lovableEvents?.captureException?.(error, {
		source: "react_error_boundary",
		route: window.location.pathname,
		...context
	}, {
		mechanism: "react_error_boundary",
		handled: false,
		severity: "error"
	});
	const message = error instanceof Response ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}` : error instanceof Error ? error.message : String(error);
	const stack = error instanceof Error ? error.stack : void 0;
	window.__lovableReportRuntimeError?.({
		message,
		...stack !== void 0 && { stack },
		filename: window.location.pathname
	});
}
var firebaseConfig = {
	apiKey: "AIzaSyAskV8AX4eZX2OXZKXHS4addn8cv-Bm9pY",
	authDomain: "hydranet-e071d.firebaseapp.com",
	databaseURL: "https://hydranet-e071d-default-rtdb.firebaseio.com",
	projectId: "hydranet-e071d",
	storageBucket: "hydranet-e071d.firebasestorage.app",
	messagingSenderId: "781622805026",
	appId: "1:781622805026:web:d86cefd09a285c3130407b",
	measurementId: "G-KVQ00HKPQE"
};
var requiredConfig = Object.entries(firebaseConfig).filter(([, value]) => !value);
var firebaseReady = requiredConfig.length === 0;
var missingFirebaseKeys = requiredConfig.map(([key]) => key);
var app = firebaseReady ? getApps().length ? getApp() : initializeApp(firebaseConfig) : null;
var auth = app ? getAuth(app) : null;
var db = app ? getFirestore(app) : null;
if (auth) setPersistence(auth, browserLocalPersistence).catch((error) => {
	console.warn("Could not persist admin session:", error);
});
function NotFoundComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-7xl font-bold text-foreground",
					children: "404"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-4 text-xl font-semibold text-foreground",
					children: "Page not found"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "The page you're looking for doesn't exist or has been moved."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-6",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/",
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Go home"
					})
				})
			]
		})
	});
}
function ErrorComponent({ error, reset }) {
	console.error(error);
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		reportLovableError(error, { boundary: "tanstack_root_error_component" });
	}, [error]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-md text-center",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "text-xl font-semibold tracking-tight text-foreground",
					children: "This page didn't load"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Something went wrong on our end. You can try refreshing or head back home."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-6 flex flex-wrap justify-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						onClick: () => {
							router.invalidate();
							reset();
						},
						className: "inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground transition-colors hover:bg-primary/90",
						children: "Try again"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "/",
						className: "inline-flex items-center justify-center rounded-md border border-input bg-background px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-accent",
						children: "Go home"
					})]
				})
			]
		})
	});
}
var Route$9 = createRootRouteWithContext()({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Smart Energy" },
			{
				name: "description",
				content: "Real-time monitoring and control for connected electrical assets, energy use and costs."
			},
			{
				name: "author",
				content: "Smart Energy"
			},
			{
				property: "og:title",
				content: "Smart Energy"
			},
			{
				property: "og:description",
				content: "Real-time monitoring and control for connected electrical assets, energy use and costs."
			},
			{
				property: "og:type",
				content: "website"
			},
			{
				name: "twitter:card",
				content: "summary_large_image"
			}
		],
		links: [
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Inter+Tight:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap"
			},
			{
				rel: "icon",
				href: "/favicon.svg",
				type: "image/svg+xml"
			},
			{
				rel: "apple-touch-icon",
				href: "/favicon.svg"
			},
			{
				rel: "manifest",
				href: "/site.webmanifest"
			}
		]
	}),
	shellComponent: RootShell,
	component: RootComponent,
	notFoundComponent: NotFoundComponent,
	errorComponent: ErrorComponent
});
function RootShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", { children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})] })]
	});
}
function RootComponent() {
	const { queryClient } = Route$9.useRouteContext();
	const [user, setUser] = (0, import_react.useState)(null);
	const [authState, setAuthState] = (0, import_react.useState)("loading");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [submitting, setSubmitting] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!auth) {
			setUser(null);
			setAuthState("guest");
			return;
		}
		return onAuthStateChanged(auth, (nextUser) => {
			setUser(nextUser);
			setAuthState(nextUser ? "ready" : "guest");
		});
	}, []);
	async function handleSignIn(event) {
		event.preventDefault();
		if (!auth) return;
		try {
			setSubmitting(true);
			setError(null);
			await signInWithEmailAndPassword(auth, email.trim(), password);
		} catch (signinError) {
			setError(signinError instanceof Error ? signinError.message : "Sign in failed.");
		} finally {
			setSubmitting(false);
		}
	}
	if (!firebaseReady) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "max-w-lg rounded-2xl border border-border bg-card p-8 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "Configuration required"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-2xl font-semibold text-foreground",
					children: "Add Firebase keys to Web1/.env"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2 text-sm text-muted-foreground",
					children: missingFirebaseKeys.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", key] }, key))
				})
			]
		})
	});
	if (authState === "loading") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-sm text-muted-foreground",
			children: "Loading Firebase session…"
		})
	});
	if (authState === "guest") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-screen items-center justify-center bg-background px-4",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "w-full max-w-md rounded-2xl border border-border bg-card p-6 shadow-sm",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-[0.18em] text-muted-foreground",
					children: "HydraNet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-3 text-2xl font-semibold text-foreground",
					children: "Sign in to the operations dashboard"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted-foreground",
					children: "Use your Firebase admin account to load the live device data."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					onSubmit: handleSignIn,
					className: "mt-6 space-y-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-2 block text-sm font-medium text-foreground",
								children: "Email"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "email",
								value: email,
								onChange: (event) => setEmail(event.target.value),
								className: "h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none ring-0 placeholder:text-muted-foreground",
								placeholder: "admin@company.com",
								required: true
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "block",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "mb-2 block text-sm font-medium text-foreground",
								children: "Password"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "password",
								value: password,
								onChange: (event) => setPassword(event.target.value),
								className: "h-11 w-full rounded-lg border border-input bg-background px-3 text-sm outline-none ring-0 placeholder:text-muted-foreground",
								placeholder: "••••••••",
								required: true
							})]
						}),
						error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive",
							children: error
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							disabled: submitting,
							className: "inline-flex h-11 w-full items-center justify-center rounded-lg bg-primary px-4 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-70",
							children: submitting ? "Signing in…" : "Sign in"
						})
					]
				})
			]
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
		client: queryClient,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "fixed right-4 top-4 z-50",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => auth && signOut(auth),
					className: "rounded-lg border border-border bg-card px-3 py-2 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground",
					children: ["Sign out ", user?.email ? `· ${user.email}` : ""]
				})
			})]
		})
	});
}
var $$splitComponentImporter$8 = () => import("./routes-C1NEC8_N.mjs");
var Route$8 = createFileRoute("/")({
	head: () => ({ meta: [
		{ title: "Operations Overview | Smart Energy" },
		{
			name: "description",
			content: "Live overview of connected electrical assets, load, relay states, energy consumption and cost across every Smart Energy site."
		},
		{
			property: "og:title",
			content: "Operations Overview | Smart Energy"
		},
		{
			property: "og:description",
			content: "Monitor devices, energy use, costs and alerts in real time from one operations dashboard."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$8, "component")
});
var $$splitComponentImporter$7 = () => import("./alerts-CwjdYwLD.mjs");
var Route$7 = createFileRoute("/alerts")({
	head: () => ({ meta: [
		{ title: "Alerts & Events | Smart Energy" },
		{
			name: "description",
			content: "Critical faults, threshold warnings and relay events across all connected electrical assets."
		},
		{
			property: "og:title",
			content: "Alerts & Events | Smart Energy"
		},
		{
			property: "og:description",
			content: "Acknowledge faults, warnings and relay events from one queue."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$7, "component")
});
var $$splitComponentImporter$6 = () => import("./costs-BTelE0PT.mjs");
var Route$6 = createFileRoute("/costs")({
	head: () => ({ meta: [
		{ title: "Cost Management | Smart Energy" },
		{
			name: "description",
			content: "Track energy spend against budget, tariff bands and per-site cost allocation for connected assets."
		},
		{
			property: "og:title",
			content: "Cost Management | Smart Energy"
		},
		{
			property: "og:description",
			content: "Energy spend, budget variance and per-site cost allocation."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$6, "component")
});
var $$splitComponentImporter$5 = () => import("./devices-Ues-DFOP.mjs");
var Route$5 = createFileRoute("/devices")({
	head: () => ({ meta: [
		{ title: "Connected Devices | Smart Energy" },
		{
			name: "description",
			content: "Inventory and live state of every connected electrical asset, including relay control and load telemetry."
		},
		{
			property: "og:title",
			content: "Connected Devices | Smart Energy"
		},
		{
			property: "og:description",
			content: "Monitor and switch relay-controlled assets across all sites."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$5, "component")
});
var $$splitComponentImporter$4 = () => import("./energy-uqXYhf_G.mjs");
var Route$4 = createFileRoute("/energy")({
	head: () => ({ meta: [
		{ title: "Energy Analytics | Smart Energy" },
		{
			name: "description",
			content: "Consumption profiles, peak demand, load factor and site-level energy breakdown for connected assets."
		},
		{
			property: "og:title",
			content: "Energy Analytics | Smart Energy"
		},
		{
			property: "og:description",
			content: "Analyse consumption, peak demand and load factor across every site."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$4, "component")
});
var $$splitComponentImporter$3 = () => import("./exports-Cm4cMhn2.mjs");
var Route$3 = createFileRoute("/exports")({
	head: () => ({ meta: [
		{ title: "Data Exports | Smart Energy" },
		{
			name: "description",
			content: "Generate and download consumption, cost and relay event reports in CSV, XLSX or PDF format."
		},
		{
			property: "og:title",
			content: "Data Exports | Smart Energy"
		},
		{
			property: "og:description",
			content: "Build and download operational energy reports on demand."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./reliability-DtgpgIjE.mjs");
var Route$2 = createFileRoute("/reliability")({
	head: () => ({ meta: [
		{ title: "Reliability & Safety | Smart Energy" },
		{
			name: "description",
			content: "Fleet uptime, SLA compliance, mean time to recover and safety protection status across all connected assets."
		},
		{
			property: "og:title",
			content: "Reliability & Safety | Smart Energy"
		},
		{
			property: "og:description",
			content: "Monitor uptime, SLA, incident response and electrical safety across the fleet."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./settings-DC9ySRGZ.mjs");
var Route$1 = createFileRoute("/settings")({
	head: () => ({ meta: [
		{ title: "Platform Settings | Smart Energy" },
		{
			name: "description",
			content: "Configure organisation details, tariff rates, alert thresholds and notification channels for Smart Energy."
		},
		{
			property: "og:title",
			content: "Platform Settings | Smart Energy"
		},
		{
			property: "og:description",
			content: "Manage tariffs, thresholds and notification preferences."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./sustainability-C6Y5AD6P.mjs");
var Route = createFileRoute("/sustainability")({
	head: () => ({ meta: [
		{ title: "Sustainability & Carbon | Smart Energy" },
		{
			name: "description",
			content: "Carbon footprint, renewable energy mix, emissions trend and efficiency recommendations across the Smart Energy fleet."
		},
		{
			property: "og:title",
			content: "Sustainability & Carbon | Smart Energy"
		},
		{
			property: "og:description",
			content: "Track fleet CO₂ emissions, renewable share and efficiency savings in real time."
		}
	] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
var rootRouteChildren = {
	IndexRoute: Route$8.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$9
	}),
	AlertsRoute: Route$7.update({
		id: "/alerts",
		path: "/alerts",
		getParentRoute: () => Route$9
	}),
	CostsRoute: Route$6.update({
		id: "/costs",
		path: "/costs",
		getParentRoute: () => Route$9
	}),
	DevicesRoute: Route$5.update({
		id: "/devices",
		path: "/devices",
		getParentRoute: () => Route$9
	}),
	EnergyRoute: Route$4.update({
		id: "/energy",
		path: "/energy",
		getParentRoute: () => Route$9
	}),
	ExportsRoute: Route$3.update({
		id: "/exports",
		path: "/exports",
		getParentRoute: () => Route$9
	}),
	ReliabilityRoute: Route$2.update({
		id: "/reliability",
		path: "/reliability",
		getParentRoute: () => Route$9
	}),
	SettingsRoute: Route$1.update({
		id: "/settings",
		path: "/settings",
		getParentRoute: () => Route$9
	}),
	SustainabilityRoute: Route.update({
		id: "/sustainability",
		path: "/sustainability",
		getParentRoute: () => Route$9
	})
};
var routeTree = Route$9._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
var getRouter = () => {
	const queryClient = new QueryClient();
	return createRouter({
		routeTree,
		context: { queryClient },
		scrollRestoration: true,
		defaultPreloadStaleTime: 0
	});
};
//#endregion
export { auth as n, db as r, router_exports as t };
