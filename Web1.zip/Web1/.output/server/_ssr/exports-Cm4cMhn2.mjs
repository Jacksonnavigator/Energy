import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { D as Download, E as FileSpreadsheet, T as FileText, l as Table2 } from "../_libs/lucide-react.mjs";
import { n as cn, r as useHydranetDashboardData, t as AppShell } from "./dashboard-data-10Pg--aE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/exports-Cm4cMhn2.js
var import_jsx_runtime = require_jsx_runtime();
var templates = [
	{
		name: "Consumption report",
		desc: "Interval kWh per device and site",
		icon: Table2
	},
	{
		name: "Cost allocation",
		desc: "Spend split by site and tariff band",
		icon: FileSpreadsheet
	},
	{
		name: "Relay event log",
		desc: "Every switch action with actor and time",
		icon: FileText
	}
];
function ExportsPage() {
	const { exportsHistory } = useHydranetDashboardData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Exports",
		subtitle: "Reports and scheduled data deliveries",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 md:grid-cols-3",
			children: templates.map(({ name, desc, icon: Icon }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "card-surface flex flex-col p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "grid h-10 w-10 place-items-center rounded-xl bg-accent text-accent-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 text-sm font-semibold",
						children: name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 flex-1 text-xs text-muted-foreground",
						children: desc
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						className: "mt-4 inline-flex h-9 items-center justify-center gap-2 rounded-lg border border-border bg-secondary text-xs font-medium transition-colors hover:bg-accent",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-3.5 w-3.5" }), " Generate"]
					})
				]
			}, name))
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "card-surface mt-6 overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border px-5 py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Recent exports"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: exportsHistory.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm font-medium",
							children: e.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "truncate text-xs text-muted-foreground",
							children: [
								e.format,
								" · ",
								e.size,
								" · ",
								e.created
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex shrink-0 items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("rounded-full px-2.5 py-1 text-[11px] font-medium", e.status === "Ready" ? "bg-success/12 text-success" : "bg-secondary text-muted-foreground"),
							children: e.status
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": `Download ${e.name}`,
							className: "grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:text-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "h-4 w-4" })
						})]
					})]
				}, e.id))
			})]
		})]
	});
}
//#endregion
export { ExportsPage as component };
