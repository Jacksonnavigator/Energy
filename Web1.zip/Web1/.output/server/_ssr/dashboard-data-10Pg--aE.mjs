import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { g as Link, l as useRouterState } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as onAuthStateChanged } from "../_libs/firebase__auth+tslib.mjs";
import "../_libs/firebase.mjs";
import { a as limit, c as query, n as collectionGroup, o as onSnapshot, r as doc, s as orderBy, t as collection } from "../_libs/@firebase/firestore+[...].mjs";
import { n as auth, r as db } from "./router-CWMaLdWN.mjs";
import { A as ChartColumn, D as Download, L as Activity, O as Cpu, S as LayoutDashboard, f as ShieldCheck, i as TriangleAlert, n as X, p as Settings, r as Wallet, u as Sun, v as Moon, x as Leaf, y as Menu } from "../_libs/lucide-react.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/dashboard-data-10Pg--aE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var nav = [
	{
		to: "/",
		label: "Overview",
		icon: LayoutDashboard
	},
	{
		to: "/devices",
		label: "Devices",
		icon: Cpu
	},
	{
		to: "/energy",
		label: "Energy",
		icon: ChartColumn
	},
	{
		to: "/sustainability",
		label: "Sustainability",
		icon: Leaf
	},
	{
		to: "/reliability",
		label: "Reliability",
		icon: ShieldCheck
	},
	{
		to: "/costs",
		label: "Costs",
		icon: Wallet
	},
	{
		to: "/alerts",
		label: "Alerts",
		icon: TriangleAlert
	},
	{
		to: "/exports",
		label: "Exports",
		icon: Download
	},
	{
		to: "/settings",
		label: "Settings",
		icon: Settings
	}
];
function ThemeToggle() {
	const [dark, setDark] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const stored = window.localStorage.getItem("hydranet-theme");
		const isDark = stored ? stored === "dark" : window.matchMedia("(prefers-color-scheme: dark)").matches;
		setDark(isDark);
		document.documentElement.classList.toggle("dark", isDark);
	}, []);
	const toggle = () => {
		const next = !dark;
		setDark(next);
		document.documentElement.classList.toggle("dark", next);
		window.localStorage.setItem("hydranet-theme", next ? "dark" : "light");
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		onClick: toggle,
		"aria-label": "Toggle color theme",
		className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-border bg-card text-muted-foreground transition-colors hover:text-foreground",
		children: dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, { className: "h-4 w-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, { className: "h-4 w-4" })
	});
}
function NavList({ onNavigate }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex flex-col gap-1",
		children: nav.map(({ to, label, icon: Icon }) => {
			const active = pathname === to;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to,
				onClick: onNavigate,
				className: cn("group flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors", active ? "bg-sidebar-accent text-sidebar-accent-foreground" : "text-muted-foreground hover:bg-sidebar-accent/60 hover:text-sidebar-foreground"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("h-4 w-4 shrink-0", active && "text-primary") }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "truncate",
					children: label
				})]
			}, to);
		})
	});
}
function Brand() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 items-center gap-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Activity, { className: "h-4.5 w-4.5" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0 leading-tight",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-sm font-semibold tracking-tight",
				children: "Smart Energy"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "truncate text-[11px] text-muted-foreground",
				children: "Energy Intelligence"
			})]
		})]
	});
}
function AppShell({ title, subtitle, actions, children }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "fixed inset-y-0 left-0 hidden w-64 flex-col border-r border-sidebar-border bg-sidebar px-4 py-5 lg:flex",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-7 flex-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label-eyebrow px-3 pb-2",
							children: "Operations"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavList, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "card-surface p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium",
							children: "Grid status"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 flex items-center gap-1.5 text-xs text-muted-foreground",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-1.5 w-1.5 rounded-full bg-success" }), "Nominal · 49.98 Hz"]
						})]
					})
				]
			}),
			open && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-40 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "absolute inset-0 bg-foreground/40",
					onClick: () => setOpen(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute inset-y-0 left-0 flex w-64 flex-col border-r border-sidebar-border bg-sidebar px-4 py-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							"aria-label": "Close menu",
							onClick: () => setOpen(false),
							className: "text-muted-foreground",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "h-5 w-5" })
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-7 flex-1",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavList, { onNavigate: () => setOpen(false) })
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "lg:pl-64",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
					className: "sticky top-0 z-30 border-b border-border bg-background/85 backdrop-blur",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-7xl grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-4 py-4 sm:px-6 lg:px-8",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								"aria-label": "Open menu",
								onClick: () => setOpen(true),
								className: "grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-border text-muted-foreground lg:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
									className: "truncate text-lg font-semibold tracking-tight sm:text-xl",
									children: title
								}), subtitle && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-xs text-muted-foreground sm:text-sm",
									children: subtitle
								})]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex shrink-0 items-center gap-2",
							children: [
								actions,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hidden h-9 items-center gap-2 rounded-lg border border-border bg-card px-2.5 sm:flex",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "grid h-6 w-6 place-items-center rounded-md bg-accent text-[11px] font-semibold text-accent-foreground",
										children: "JW"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs font-medium",
										children: "Jackson W."
									})]
								})
							]
						})]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 lg:py-8",
					children
				})]
			})
		]
	});
}
var TIMEZONE = "Africa/Dar_es_Salaam (UTC+3)";
var GRID_EMISSION_FACTOR_KGCO2_PER_KWH = .43;
var defaultPlatformSettings = {
	timezone: TIMEZONE,
	currency: "TZS",
	tariffPerKwh: 0,
	maxPower: 1e4,
	maxDailyCost: 5e4,
	maxDailyEnergy: 200
};
function normalizePlatformSettings(raw) {
	return {
		timezone: String(raw?.timezone ?? defaultPlatformSettings.timezone),
		currency: "TZS",
		tariffPerKwh: Number(raw?.tariffPerKwh ?? defaultPlatformSettings.tariffPerKwh),
		maxPower: Number(raw?.maxPower ?? defaultPlatformSettings.maxPower),
		maxDailyCost: Number(raw?.maxDailyCost ?? defaultPlatformSettings.maxDailyCost),
		maxDailyEnergy: Number(raw?.maxDailyEnergy ?? defaultPlatformSettings.maxDailyEnergy)
	};
}
function getTimeRangeHours(range) {
	switch (range) {
		case "hour": return 1;
		case "day": return 24;
		case "week": return 168;
		case "month": return 720;
	}
}
var touBands = [
	{
		id: "peak",
		label: "Peak",
		window: "18:00 – 22:00",
		multiplier: 1.35
	},
	{
		id: "standard",
		label: "Standard",
		window: "06:00 – 18:00",
		multiplier: 1
	},
	{
		id: "offpeak",
		label: "Off-peak",
		window: "22:00 – 06:00",
		multiplier: .72
	}
];
var periodOf = (hour) => hour >= 18 && hour < 22 ? "peak" : hour >= 6 && hour < 18 ? "standard" : "offpeak";
var currency = (n) => new Intl.NumberFormat("en-TZ", {
	style: "currency",
	currency: "TZS",
	maximumFractionDigits: 0
}).format(n);
var STALE_MS = 3e5;
function normalizeTimestamp(value) {
	if (!value) return null;
	const v = value;
	if (typeof v.toDate === "function") return v.toDate();
	if (typeof v.seconds === "number") return /* @__PURE__ */ new Date(v.seconds * 1e3);
	if (typeof value === "number") return new Date(value < 0xe8d4a51000 ? value * 1e3 : value);
	if (value instanceof Date) return value;
	return null;
}
function formatRelativeTime(date) {
	const diffMs = Date.now() - date.getTime();
	const seconds = Math.max(1, Math.round(diffMs / 1e3));
	if (seconds < 60) return `${seconds}s ago`;
	const minutes = Math.round(seconds / 60);
	if (minutes < 60) return `${minutes}m ago`;
	const hours = Math.round(minutes / 60);
	if (hours < 24) return `${hours}h ago`;
	return `${Math.round(hours / 24)}d ago`;
}
function normalizeDevice(id, raw) {
	const telemetry = raw.lastTelemetry || raw.telemetry || {};
	const updatedAt = normalizeTimestamp(telemetry.ts) || normalizeTimestamp(raw.updatedAt) || null;
	const stale = !!updatedAt && Date.now() - updatedAt.getTime() > STALE_MS;
	const isOnline = Boolean(raw.isOnline) && !stale;
	const desiredRelay = raw.desiredRelayState ? String(raw.desiredRelayState).toUpperCase() : null;
	const relayState = raw.relayState ? String(raw.relayState).toUpperCase() : null;
	const relay = relayState ? relayState === "ON" : desiredRelay ? desiredRelay === "ON" : Boolean(raw.isOn);
	const power = Number(telemetry.p ?? telemetry.power ?? raw.currentPower ?? 0);
	const voltage = Number(telemetry.v ?? telemetry.voltage ?? 0);
	const current = Number(telemetry.i ?? telemetry.current ?? 0);
	const energy = Number(telemetry.e ?? telemetry.energy ?? raw.energyToday ?? 0);
	const site = typeof raw.site === "string" ? raw.site : "Primary site";
	const status = !isOnline ? "offline" : stale ? "stale" : current > 0 && !relay ? "fault" : "online";
	return {
		id,
		name: String(raw.name ?? id),
		site,
		status,
		relay,
		load: Number((power / 1e3).toFixed(1)),
		voltage,
		current,
		power_factor: Number(telemetry.pf ?? telemetry.powerFactor ?? .95),
		todayKwh: energy,
		lastSeen: updatedAt ? formatRelativeTime(updatedAt) : "No telemetry",
		command: "idle"
	};
}
function deriveCommandState(status) {
	const value = String(status ?? "idle").toLowerCase();
	if (value === "pending") return "pending";
	if (value === "confirmed" || value === "done" || value === "success") return "confirmed";
	if (value === "failed") return "failed";
	return "idle";
}
function deriveAlerts(devices, commands) {
	const generated = [];
	devices.forEach((device) => {
		if (device.status === "fault") generated.push({
			id: `${device.id}-fault`,
			severity: "critical",
			title: "Fault condition detected",
			device: `${device.id} · ${device.name}`,
			time: device.lastSeen,
			acknowledged: false
		});
		if (device.status === "stale") generated.push({
			id: `${device.id}-stale`,
			severity: "warning",
			title: "Telemetry stale",
			device: `${device.id} · ${device.name}`,
			time: device.lastSeen,
			acknowledged: false
		});
		if (device.status === "offline") generated.push({
			id: `${device.id}-offline`,
			severity: "critical",
			title: "Device unreachable",
			device: `${device.id} · ${device.name}`,
			time: device.lastSeen,
			acknowledged: false
		});
	});
	commands.filter((cmd) => cmd.status === "pending").forEach((cmd) => {
		generated.push({
			id: `cmd-${cmd.deviceId}`,
			severity: "info",
			title: "Relay command pending confirmation",
			device: cmd.deviceId,
			time: "Now",
			acknowledged: false
		});
	});
	return generated.length ? generated.slice(0, 8) : [];
}
function useHydranetDashboardData() {
	const [devices, setDevices] = (0, import_react.useState)([]);
	const [commands, setCommands] = (0, import_react.useState)([]);
	const [platformSettings, setPlatformSettings] = (0, import_react.useState)(defaultPlatformSettings);
	const [telemetryMap, setTelemetryMap] = (0, import_react.useState)(/* @__PURE__ */ new Map());
	const commandsRef = (0, import_react.useRef)(commands);
	const devicesRef = (0, import_react.useRef)(devices);
	const telemetryMapRef = (0, import_react.useRef)(telemetryMap);
	const telemetryUnsubsRef = (0, import_react.useRef)(/* @__PURE__ */ new Map());
	(0, import_react.useEffect)(() => {
		commandsRef.current = commands;
		devicesRef.current = devices;
		telemetryMapRef.current = telemetryMap;
	}, [
		commands,
		devices,
		telemetryMap
	]);
	(0, import_react.useEffect)(() => {
		if (!db) {
			setDevices([]);
			setCommands([]);
			setPlatformSettings(defaultPlatformSettings);
			return;
		}
		let unsubDevices;
		let unsubCommands;
		let unsubPlatform;
		let unsubscribeAuth;
		const attachTelemetryListener = (deviceId) => {
			telemetryUnsubsRef.current.get(deviceId)?.();
			const unsub = onSnapshot(query(collection(db, "devices", deviceId, "telemetry"), orderBy("ts", "desc"), limit(72)), (snapshot) => {
				const deviceName = devicesRef.current.find((d) => d.id === deviceId)?.name ?? deviceId;
				const points = snapshot.docs.map((docSnap) => {
					const raw = docSnap.data();
					const ts = normalizeTimestamp(raw.ts) ?? /* @__PURE__ */ new Date();
					return {
						id: docSnap.id,
						ts: ts.getTime(),
						power: Number(raw.p ?? raw.power ?? 0),
						voltage: Number(raw.v ?? raw.voltage ?? 0),
						current: Number(raw.i ?? raw.current ?? 0),
						energy: Number(raw.e ?? raw.energy ?? 0),
						pf: Number(raw.pf ?? raw.powerFactor ?? .95),
						deviceId,
						deviceName
					};
				}).sort((a, b) => a.ts - b.ts);
				setTelemetryMap((prev) => {
					const next = new Map(prev);
					next.set(deviceId, points);
					return next;
				});
			}, (error) => {
				console.warn(`Unable to load telemetry for ${deviceId}:`, error);
				setTelemetryMap((prev) => {
					const next = new Map(prev);
					next.set(deviceId, []);
					return next;
				});
			});
			telemetryUnsubsRef.current.set(deviceId, unsub);
		};
		const attachDeviceListener = () => {
			unsubDevices?.();
			unsubDevices = onSnapshot(collection(db, "devices"), (snapshot) => {
				const commandMap = new Map(commandsRef.current.map((command) => [command.deviceId, command]));
				const next = snapshot.docs.map((docSnap) => {
					const raw = docSnap.data();
					const normalized = normalizeDevice(docSnap.id, raw);
					const latest = commandMap.get(docSnap.id);
					if (latest) normalized.command = deriveCommandState(latest.status);
					normalized.telemetry = telemetryMapRef.current.get(docSnap.id) || [];
					return normalized;
				});
				setDevices(next);
				snapshot.docs.forEach((doc) => {
					attachTelemetryListener(doc.id);
				});
			}, (error) => {
				console.warn("Unable to load devices from Firestore:", error);
				setDevices([]);
			});
		};
		if (auth) unsubscribeAuth = onAuthStateChanged(auth, () => {
			attachDeviceListener();
		});
		else attachDeviceListener();
		unsubCommands = onSnapshot(query(collectionGroup(db, "commands"), orderBy("createdAtMs", "desc"), limit(100)), (snapshot) => {
			const rows = snapshot.docs.map((docSnap) => {
				const raw = docSnap.data();
				const parent = docSnap.ref.parent.parent;
				return {
					deviceId: String(parent?.id ?? "UNKNOWN"),
					cmd: String(raw.cmd ?? "").toUpperCase(),
					status: String(raw.status ?? "pending").toLowerCase(),
					createdAtMs: Number(raw.createdAtMs ?? Date.now())
				};
			});
			setCommands(rows);
		}, (error) => {
			console.warn("Unable to load command history:", error);
			setCommands([]);
		});
		unsubPlatform = onSnapshot(doc(db, "appConfig", "platform"), (snapshot) => {
			setPlatformSettings(normalizePlatformSettings(snapshot.exists() ? snapshot.data() : null));
		}, (error) => {
			console.warn("Unable to load platform settings:", error);
			setPlatformSettings(defaultPlatformSettings);
		});
		return () => {
			unsubscribeAuth?.();
			unsubDevices?.();
			unsubCommands?.();
			unsubPlatform?.();
			telemetryUnsubsRef.current.forEach((unsub) => unsub());
			telemetryUnsubsRef.current.clear();
		};
	}, [auth]);
	const alerts = (0, import_react.useMemo)(() => deriveAlerts(devices, commands.map(({ deviceId, status }) => ({
		deviceId,
		status
	}))), [devices, commands]);
	const tariffPerKwh = platformSettings.tariffPerKwh || 0;
	const allTelemetry = (0, import_react.useMemo)(() => Array.from(telemetryMap.values()).flat().sort((a, b) => a.ts - b.ts), [telemetryMap]);
	const consumptionSeries = (0, import_react.useMemo)(() => {
		if (!allTelemetry.length) return [];
		const grouped = /* @__PURE__ */ new Map();
		allTelemetry.forEach((point) => {
			const hour = new Date(point.ts).getHours();
			grouped.set(hour, (grouped.get(hour) ?? 0) + point.power / 1e3);
		});
		return Array.from({ length: 24 }, (_, hour) => {
			const kwh = (grouped.get(hour) ?? 0) * .25;
			return {
				t: `${String(hour).padStart(2, "0")}:00`,
				kwh: Number(Math.max(0, kwh).toFixed(1)),
				cost: Number((kwh * tariffPerKwh).toFixed(1))
			};
		});
	}, [allTelemetry, tariffPerKwh]);
	const siteBreakdown = (0, import_react.useMemo)(() => {
		if (!devices.length) return [];
		const grouped = /* @__PURE__ */ new Map();
		devices.forEach((device) => {
			const existing = grouped.get(device.site) ?? {
				site: device.site,
				kwh: 0,
				cost: 0
			};
			existing.kwh += device.todayKwh;
			existing.cost += device.todayKwh * tariffPerKwh;
			grouped.set(device.site, existing);
		});
		return Array.from(grouped.values()).sort((a, b) => b.kwh - a.kwh);
	}, [devices, tariffPerKwh]);
	const costTrend = (0, import_react.useMemo)(() => {
		if (!allTelemetry.length) return [];
		const bucketed = /* @__PURE__ */ new Map();
		allTelemetry.forEach((point) => {
			const date = new Date(point.ts);
			const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
			bucketed.set(key, (bucketed.get(key) ?? 0) + point.power / 1e3 * .25);
		});
		const months = [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		];
		const now = /* @__PURE__ */ new Date();
		return months.map((m, index) => {
			const date = new Date(now.getFullYear(), index, 1);
			const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
			const kwh = bucketed.get(key) ?? 0;
			return {
				m,
				cost: Number((kwh * tariffPerKwh).toFixed(0)),
				budget: Number(((kwh || 1) * tariffPerKwh * 1.1).toFixed(0))
			};
		}).slice(Math.max(0, now.getMonth() - 5));
	}, [allTelemetry, tariffPerKwh]);
	const renewableMix = (0, import_react.useMemo)(() => {
		if (!allTelemetry.length) return [
			{
				source: "Hydro",
				pct: 0,
				color: "var(--chart-3)"
			},
			{
				source: "Solar PV",
				pct: 0,
				color: "var(--chart-1)"
			},
			{
				source: "Thermal (gas/diesel)",
				pct: 0,
				color: "var(--chart-2)"
			},
			{
				source: "Biogas",
				pct: 0,
				color: "var(--chart-4)"
			}
		];
		return [
			{
				source: "Hydro",
				pct: 0,
				color: "var(--chart-3)"
			},
			{
				source: "Solar PV",
				pct: 0,
				color: "var(--chart-1)"
			},
			{
				source: "Thermal (gas/diesel)",
				pct: 100,
				color: "var(--chart-2)"
			},
			{
				source: "Biogas",
				pct: 0,
				color: "var(--chart-4)"
			}
		];
	}, [allTelemetry]);
	const emissionsTrend = (0, import_react.useMemo)(() => {
		if (!allTelemetry.length) return [];
		const byMonth = /* @__PURE__ */ new Map();
		allTelemetry.forEach((point) => {
			const date = new Date(point.ts);
			const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
			byMonth.set(monthKey, (byMonth.get(monthKey) ?? 0) + point.power / 1e3 * .25);
		});
		if (byMonth.size < 2) return [];
		const months = [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		];
		return Array.from(byMonth.entries()).sort(([keyA], [keyB]) => keyA.localeCompare(keyB)).slice(-6).map(([monthKey, kwh]) => {
			const [year, month] = monthKey.split("-");
			const monthIndex = Number(month) - 1;
			const monthName = months[monthIndex];
			const co2 = Math.round(kwh * GRID_EMISSION_FACTOR_KGCO2_PER_KWH);
			const baseline = Math.round(co2 * 1.15);
			return {
				m: monthName,
				co2,
				baseline,
				avoided: Math.max(0, baseline - co2)
			};
		});
	}, [allTelemetry, GRID_EMISSION_FACTOR_KGCO2_PER_KWH]);
	const recommendations = (0, import_react.useMemo)(() => {
		if (!devices.length) return [];
		const generated = [];
		devices.forEach((device) => {
			if (device.status === "fault" || device.status === "offline") generated.push({
				id: `rec-${device.id}`,
				title: device.status === "fault" ? "Correct power quality at site" : "Restore telemetry connectivity",
				detail: `${device.name} is ${device.status}. Review the relay and communications path to restore stable operation.`,
				device: `${device.id} · ${device.name}`,
				savingKwh: 0,
				savingTzs: 0,
				co2SavedKg: 0,
				priority: "high",
				category: device.status === "fault" ? "Power quality" : "Reliability"
			});
			if (device.status === "stale" && device.todayKwh > 0) generated.push({
				id: `rec-${device.id}-schedule`,
				title: "Reschedule idle overnight load",
				detail: `${device.name} has stale telemetry and some overnight draw. Confirm the schedule and avoid unnecessary off-hours consumption.`,
				device: `${device.id} · ${device.name}`,
				savingKwh: Math.max(25, Math.round(device.todayKwh * .08)),
				savingTzs: Math.max(15e3, Math.round(device.todayKwh * .08 * platformSettings.tariffPerKwh || 0)),
				co2SavedKg: Math.max(0, Math.round(Math.max(25, Math.round(device.todayKwh * .08)) * GRID_EMISSION_FACTOR_KGCO2_PER_KWH)),
				priority: "medium",
				category: "Scheduling"
			});
		});
		return generated.length ? generated.slice(0, 4) : [];
	}, [
		devices,
		GRID_EMISSION_FACTOR_KGCO2_PER_KWH,
		platformSettings.tariffPerKwh
	]);
	const incidentHistory = (0, import_react.useMemo)(() => {
		if (!devices.length) return [];
		return devices.filter((device) => device.status === "fault" || device.status === "offline" || device.status === "stale").map((device) => ({
			id: `INC-${device.id}`,
			title: device.status === "fault" ? "Reactive or protection alert" : device.status === "offline" ? "Device unreachable" : "Telemetry stale",
			device: `${device.id} · ${device.name}`,
			severity: device.status === "fault" ? "critical" : device.status === "offline" ? "critical" : "warning",
			detected: "Recent",
			duration: "—",
			rootCause: device.status === "fault" ? "Load protection threshold exceeded" : device.status === "offline" ? "Gateway or network interruption" : "Polling timeout"
		}));
	}, [devices]);
	const safetyStatus = (0, import_react.useMemo)(() => ({
		relaySafelyControlled: devices.filter((device) => device.relay).length,
		faultProtectionArmed: devices.filter((device) => device.status !== "fault").length,
		overloadProtected: devices.filter((device) => device.load && device.load < 100).length,
		groundFaults: devices.filter((device) => device.status === "fault").length,
		lastSafetyAudit: platformSettings.timezone || "Unknown"
	}), [devices, platformSettings.timezone]);
	const uptimeBySite = (0, import_react.useMemo)(() => {
		if (!devices.length) return [];
		const grouped = /* @__PURE__ */ new Map();
		devices.forEach((device) => {
			const entry = grouped.get(device.site) ?? {
				site: device.site,
				uptime: 100,
				sla: 99.5
			};
			entry.uptime = device.status === "offline" ? Math.min(entry.uptime, 99) : entry.uptime;
			grouped.set(device.site, entry);
		});
		return Array.from(grouped.values());
	}, [devices]);
	const hourlyProfile = (0, import_react.useMemo)(() => {
		if (!allTelemetry.length) return [];
		const grouped = /* @__PURE__ */ new Map();
		allTelemetry.forEach((point) => {
			const hour = new Date(point.ts).getHours();
			grouped.set(hour, (grouped.get(hour) ?? 0) + point.power / 1e3);
		});
		return Array.from({ length: 24 }, (_, hour) => {
			const kwh = (grouped.get(hour) ?? 0) * .25;
			const period = periodOf(hour);
			const multiplier = touBands.find((band) => band.id === period)?.multiplier ?? 1;
			const cost = kwh * tariffPerKwh * multiplier;
			return {
				hour,
				t: `${String(hour).padStart(2, "0")}:00`,
				kwh: Number(Math.max(0, kwh).toFixed(1)),
				cost: Number(cost.toFixed(0)),
				period
			};
		});
	}, [allTelemetry, tariffPerKwh]);
	return {
		devices,
		alerts,
		commands,
		consumptionSeries,
		siteBreakdown,
		costTrend,
		renewableMix,
		emissionsTrend,
		sustainabilityEquivalents: {
			trees: Math.max(0, Math.round(devices.reduce((sum, device) => sum + Math.max(0, device.todayKwh), 0) * .22)),
			kmAvoided: Math.max(0, Math.round(devices.reduce((sum, device) => sum + Math.max(0, device.todayKwh), 0) * 4.8)),
			homesPowered: Math.max(0, Math.round(devices.reduce((sum, device) => sum + Math.max(0, device.todayKwh), 0) / 220)),
			phonesCharged: Math.max(0, Math.round(devices.reduce((sum, device) => sum + Math.max(0, device.todayKwh), 0) * 420))
		},
		recommendations,
		reliabilityMetrics: {
			uptime: devices.length ? Number((devices.filter((device) => device.status === "online").length / devices.length * 100).toFixed(2)) : 0,
			mttr: devices.filter((device) => device.status === "offline" || device.status === "fault").length > 0 ? "—" : "N/A",
			incidents30d: incidentHistory.length,
			avgResponse: devices.filter((device) => device.status === "offline" || device.status === "fault").length > 0 ? "—" : "N/A",
			slaTarget: 99.5,
			compliance: devices.length ? devices.filter((device) => device.status === "online").length / devices.length >= .995 : false
		},
		uptimeBySite,
		incidentHistory,
		incidents: incidentHistory,
		safetyStatus,
		exportsHistory: [],
		recentActivity: [],
		hourlyProfile,
		telemetryByDevice: telemetryMap,
		allTelemetry,
		platformSettings,
		tariffPerKwh,
		TARIFF_TZS_PER_KWH: 0,
		TIMEZONE,
		GRID_EMISSION_FACTOR_KGCO2_PER_KWH,
		currency,
		touBands,
		periodOf,
		getTimeRangeHours
	};
}
//#endregion
export { cn as n, useHydranetDashboardData as r, AppShell as t };
