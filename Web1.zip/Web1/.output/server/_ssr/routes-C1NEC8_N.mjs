import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { O as Cpu, f as ShieldCheck, i as TriangleAlert, r as Wallet, t as Zap, w as Gauge, x as Leaf } from "../_libs/lucide-react.mjs";
import { n as cn, r as useHydranetDashboardData, t as AppShell } from "./dashboard-data-10Pg--aE.mjs";
import { t as StatCard } from "./StatCard-CNwaNILP.mjs";
import { a as YAxis, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, s as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C1NEC8_N.js
var import_jsx_runtime = require_jsx_runtime();
function Overview() {
	const { devices, alerts, consumptionSeries, siteBreakdown, currency, TARIFF_TZS_PER_KWH, GRID_EMISSION_FACTOR_KGCO2_PER_KWH, reliabilityMetrics, platformSettings, allTelemetry } = useHydranetDashboardData();
	const online = devices.filter((d) => d.status === "online").length;
	const totalLoad = devices.reduce((s, d) => s + d.load, 0);
	const openAlerts = alerts.filter((a) => !a.acknowledged);
	const stale = devices.filter((d) => d.status === "stale").length;
	const offline = devices.filter((d) => d.status === "offline").length;
	const faults = devices.filter((d) => d.status === "fault").length;
	const pending = devices.filter((d) => d.command === "pending").length;
	const energyToday = devices.reduce((s, d) => s + d.todayKwh, 0);
	const monthToDate = siteBreakdown.reduce((sum, site) => sum + site.cost, 0);
	const topConsumers = [...devices].sort((a, b) => b.todayKwh - a.todayKwh).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Operations Overview",
		subtitle: `All sites · ${platformSettings.timezone ? "Live telemetry" : "No data"}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Active load",
						value: totalLoad.toFixed(1),
						unit: "kW",
						icon: Zap,
						tone: "primary",
						delta: {
							value: devices.length ? "Live" : "No data",
							direction: "up",
							good: false
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Energy today",
						value: energyToday.toLocaleString(),
						unit: "kWh",
						icon: Gauge,
						delta: {
							value: devices.length ? "Live" : "No telemetry",
							direction: "down"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Spend this month",
						value: currency(monthToDate),
						icon: Wallet,
						delta: {
							value: devices.length ? "Live" : "No data",
							direction: "down"
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Devices online",
						value: `${online}/${devices.length}`,
						icon: Cpu,
						tone: openAlerts.length ? "warning" : "neutral"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "card-surface mt-4 grid grid-cols-2 gap-4 p-5 sm:grid-cols-5",
				children: [
					{
						k: "Online",
						v: online,
						c: "text-success"
					},
					{
						k: "Stale telemetry",
						v: stale,
						c: "text-warning"
					},
					{
						k: "Faults",
						v: faults,
						c: "text-destructive"
					},
					{
						k: "Offline",
						v: offline,
						c: "text-muted-foreground"
					},
					{
						k: "Pending commands",
						v: pending,
						c: "text-warning"
					}
				].map((h) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-eyebrow",
					children: h.k
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: cn("mt-1 text-xl font-semibold tabular-nums", h.c),
					children: h.v
				})] }, h.k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "truncate text-sm font-semibold",
								children: "Consumption profile"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: "Last 24 hours, aggregated across sites"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 rounded-full bg-secondary px-2.5 py-1 text-[11px] font-medium text-muted-foreground",
							children: "kWh"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: consumptionSeries,
								margin: {
									left: -18,
									right: 4,
									top: 4
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "kwhFill",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "var(--chart-1)",
											stopOpacity: .35
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "var(--chart-1)",
											stopOpacity: 0
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--border)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "t",
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 11,
											fill: "var(--muted-foreground)"
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 11,
											fill: "var(--muted-foreground)"
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: {
										background: "var(--popover)",
										border: "1px solid var(--border)",
										borderRadius: "0.75rem",
										fontSize: 12,
										color: "var(--popover-foreground)"
									} }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "kwh",
										stroke: "var(--chart-1)",
										strokeWidth: 2,
										fill: "url(#kwhFill)"
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "truncate text-sm font-semibold",
							children: "Open alerts"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/alerts",
							className: "shrink-0 text-xs font-medium text-primary",
							children: "View all"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-3",
						children: openAlerts.slice(0, 4).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-start gap-3 rounded-lg bg-secondary/60 p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, { className: cn("mt-0.5 h-4 w-4 shrink-0", a.severity === "critical" ? "text-destructive" : "text-warning") }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: a.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: [
										a.device,
										" · ",
										a.time
									]
								})]
							})]
						}, a.id))
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Top consumers today"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-3",
						children: topConsumers.length ? topConsumers.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-medium",
										children: d.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [
											d.id,
											" · ",
											d.site
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: cn("h-full rounded-full", d.load > 70 ? "bg-warning" : "bg-primary"),
											style: { width: `${Math.min(100, d.load / 90 * 100)}%` }
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shrink-0 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold tabular-nums",
									children: [d.todayKwh, " kWh"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground tabular-nums",
									children: currency(d.todayKwh * (TARIFF_TZS_PER_KWH || platformSettings.tariffPerKwh || 0))
								})]
							})]
						}, d.id)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "No device telemetry has been loaded yet."
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Cost by site"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3.5",
							children: siteBreakdown.length ? siteBreakdown.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "truncate text-sm",
									children: s.site
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "shrink-0 text-sm font-semibold tabular-nums",
									children: currency(s.cost)
								})]
							}, s.site)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "text-sm text-muted-foreground",
								children: "No site totals available yet."
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 border-t border-border pt-4 text-xs text-muted-foreground",
							children: [
								"Month-to-date tariff: ",
								platformSettings.tariffPerKwh || 0,
								" TZS/kWh."
							]
						})
					]
				})]
			}),
			allTelemetry.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-6 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Live telemetry feed"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left py-2 px-3 font-medium text-muted-foreground",
									children: "Device"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left py-2 px-3 font-medium text-muted-foreground",
									children: "Date & Time"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-right py-2 px-3 font-medium text-muted-foreground",
									children: "Power (kW)"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: allTelemetry.slice(0, 15).map((point) => {
							const date = new Date(point.ts);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 hover:bg-secondary/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 px-3",
										children: point.deviceName || "Unknown"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 px-3 text-muted-foreground",
										children: date.toLocaleString()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "text-right py-2 px-3",
										children: (point.power / 1e3).toFixed(2)
									})
								]
							}, point.id);
						}) })]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-6 grid gap-4 md:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/sustainability",
					className: "card-surface group block p-5 transition-colors hover:bg-accent/40",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-8 w-8 place-items-center rounded-lg bg-accent text-accent-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Leaf, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Sustainability snapshot"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted-foreground",
							children: [
								"Fleet carbon today:",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium text-foreground",
									children: [Math.round(energyToday * GRID_EMISSION_FACTOR_KGCO2_PER_KWH).toLocaleString(), " kgCO₂"]
								}),
								" ",
								"at ",
								GRID_EMISSION_FACTOR_KGCO2_PER_KWH,
								" kgCO₂/kWh grid factor. Track renewables, emissions trend and efficiency savings."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs font-medium text-primary",
							children: "Explore carbon & recommendations →"
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/reliability",
					className: "card-surface group block p-5 transition-colors hover:bg-accent/40",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid h-8 w-8 place-items-center rounded-lg bg-accent text-accent-foreground",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Reliability & safety"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-muted-foreground",
							children: [
								"Fleet uptime",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "font-medium text-foreground",
									children: [reliabilityMetrics.uptime || 0, "%"]
								}),
								" against a",
								" ",
								reliabilityMetrics.slaTarget,
								"% SLA, mean time to recover ",
								reliabilityMetrics.mttr,
								" and protection status."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-xs font-medium text-primary",
							children: "View uptime & incidents →"
						})
					]
				})]
			})
		]
	});
}
//#endregion
export { Overview as component };
