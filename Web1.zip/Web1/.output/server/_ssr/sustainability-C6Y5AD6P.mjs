import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { g as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { b as Lightbulb, d as Smartphone, h as Recycle, j as Car, o as TrendingDown, s as TreePine, x as Leaf } from "../_libs/lucide-react.mjs";
import { n as cn, r as useHydranetDashboardData, t as AppShell } from "./dashboard-data-10Pg--aE.mjs";
import { t as StatCard } from "./StatCard-CNwaNILP.mjs";
import { a as YAxis, d as Pie, f as Cell, l as CartesianGrid, m as Tooltip, n as PieChart, o as XAxis, p as ResponsiveContainer, s as Area, t as AreaChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sustainability-C6Y5AD6P.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var tooltipStyle = {
	background: "var(--popover)",
	border: "1px solid var(--border)",
	borderRadius: "0.75rem",
	fontSize: 12,
	color: "var(--popover-foreground)"
};
var priorityStyle = {
	high: "bg-destructive/12 text-destructive",
	medium: "bg-warning/15 text-warning",
	low: "bg-secondary text-muted-foreground"
};
function SustainabilityPage() {
	const { devices, renewableMix, emissionsTrend, sustainabilityEquivalents, recommendations: seed, GRID_EMISSION_FACTOR_KGCO2_PER_KWH, currency, allTelemetry } = useHydranetDashboardData();
	const [timeRange, setTimeRange] = (0, import_react.useState)("month");
	const energyToday = devices.reduce((s, d) => s + d.todayKwh, 0);
	const co2TodayKg = Math.round(energyToday * GRID_EMISSION_FACTOR_KGCO2_PER_KWH);
	const renewableShare = renewableMix.filter((r) => r.source === "Hydro" || r.source === "Solar PV" || r.source === "Biogas").reduce((s, r) => s + r.pct, 0);
	const lastMonth = emissionsTrend[emissionsTrend.length - 1] ?? { avoided: 0 };
	const avoidedThisMonth = Math.max(0, lastMonth?.avoided ?? 0);
	const totalPotentialSaving = Array.isArray(seed) ? seed.reduce((s, r) => s + r.savingTzs, 0) : 0;
	const totalPotentialCo2 = Array.isArray(seed) ? seed.reduce((s, r) => s + r.co2SavedKg, 0) : 0;
	const topEmitters = [...devices].map((d) => ({
		...d,
		co2Kg: Math.round(d.todayKwh * GRID_EMISSION_FACTOR_KGCO2_PER_KWH)
	})).sort((a, b) => b.co2Kg - a.co2Kg).slice(0, 5);
	const maxCo2 = Math.max(...topEmitters.map((d) => d.co2Kg), 1);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Sustainability",
		subtitle: `Carbon, renewables and efficiency · Grid factor ${GRID_EMISSION_FACTOR_KGCO2_PER_KWH} kgCO₂/kWh`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Carbon today",
						value: co2TodayKg.toLocaleString(),
						unit: "kgCO₂",
						icon: Leaf,
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Grid intensity",
						value: String(Math.round(GRID_EMISSION_FACTOR_KGCO2_PER_KWH * 1e3)),
						unit: "gCO₂/kWh",
						icon: Recycle
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Renewable share",
						value: `${renewableShare}%`,
						icon: TreePine
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "CO₂ avoided (Aug)",
						value: avoidedThisMonth.toLocaleString(),
						unit: "kgCO₂",
						icon: TrendingDown
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-sm font-semibold",
								children: "Emissions vs baseline"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted-foreground",
								children: "Fleet CO₂ emissions with no-action baseline · View by hour, day, week or month"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-1.5",
							children: [
								"hour",
								"day",
								"week",
								"month"
							].map((range) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setTimeRange(range),
								className: cn("rounded-full border px-3 py-1.5 text-[11px] font-medium capitalize transition-colors", timeRange === range ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground hover:text-foreground"),
								children: range
							}, range))
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AreaChart, {
								data: emissionsTrend,
								margin: {
									left: -18,
									right: 4,
									top: 8
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("defs", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("linearGradient", {
										id: "co2Fill",
										x1: "0",
										y1: "0",
										x2: "0",
										y2: "1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "0%",
											stopColor: "var(--chart-3)",
											stopOpacity: .35
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("stop", {
											offset: "100%",
											stopColor: "var(--chart-3)",
											stopOpacity: 0
										})]
									}) }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--border)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "m",
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 11,
											fill: "var(--muted-foreground)"
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 11,
											fill: "var(--muted-foreground)"
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, { contentStyle: tooltipStyle }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "baseline",
										name: "Baseline",
										stroke: "var(--chart-5)",
										strokeDasharray: "5 4",
										strokeWidth: 2,
										fill: "none"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Area, {
										type: "monotone",
										dataKey: "co2",
										name: "Actual",
										stroke: "var(--chart-3)",
										strokeWidth: 2,
										fill: "url(#co2Fill)"
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Energy source mix"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted-foreground",
							children: "Share of supply feeding the fleet"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 h-40",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
								width: "100%",
								height: "100%",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(PieChart, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pie, {
									data: renewableMix,
									dataKey: "pct",
									nameKey: "source",
									innerRadius: 42,
									outerRadius: 62,
									paddingAngle: 2,
									stroke: "var(--border)",
									children: renewableMix.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: r.color }, r.source))
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
									contentStyle: tooltipStyle,
									formatter: (v, n) => [`${v}%`, n]
								})] })
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-2 space-y-2",
							children: renewableMix.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center gap-2.5 text-xs",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "h-2.5 w-2.5 shrink-0 rounded-full",
										style: { background: r.color }
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "min-w-0 flex-1 truncate text-muted-foreground",
										children: r.source
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "shrink-0 font-medium tabular-nums",
										children: [r.pct, "%"]
									})
								]
							}, r.source))
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-6 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Carbon equivalents"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "What this month's avoided emissions look like in everyday terms"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4",
						children: [
							{
								icon: TreePine,
								label: "Trees absorbing CO₂ for a year",
								value: sustainabilityEquivalents.trees.toLocaleString()
							},
							{
								icon: Car,
								label: "Car km not driven",
								value: sustainabilityEquivalents.kmAvoided.toLocaleString()
							},
							{
								icon: Leaf,
								label: "Homes powered (monthly)",
								value: sustainabilityEquivalents.homesPowered.toLocaleString()
							},
							{
								icon: Smartphone,
								label: "Smartphones charged",
								value: sustainabilityEquivalents.phonesCharged.toLocaleString()
							}
						].map(({ icon: Icon, label, value }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-xl border border-border bg-secondary/40 p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "grid h-9 w-9 place-items-center rounded-lg bg-accent text-accent-foreground",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-xl font-semibold tabular-nums",
									children: value
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-xs text-muted-foreground",
									children: label
								})
							]
						}, label))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Top emitters today"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-3",
						children: topEmitters.map((d) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate text-sm font-medium",
										children: d.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "truncate text-xs text-muted-foreground",
										children: [
											d.id,
											" · ",
											d.site
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
										className: "mt-2 h-1.5 w-full overflow-hidden rounded-full bg-secondary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "h-full rounded-full bg-chart-3",
											style: { width: `${d.co2Kg / maxCo2 * 100}%` }
										})
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shrink-0 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm font-semibold tabular-nums",
									children: [d.co2Kg, " kg"]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs text-muted-foreground tabular-nums",
									children: [d.todayKwh, " kWh"]
								})]
							})]
						}, d.id))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecommendationsCard, {
					totalPotentialSaving,
					totalPotentialCo2,
					currency,
					recommendations: seed
				})]
			}),
			allTelemetry && allTelemetry.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-6 p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold mb-4",
						children: "Detailed emissions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left py-2 px-3 font-medium text-muted-foreground",
										children: "Device"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-left py-2 px-3 font-medium text-muted-foreground",
										children: "Date & Time"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-right py-2 px-3 font-medium text-muted-foreground",
										children: "Power (kW)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "text-right py-2 px-3 font-medium text-muted-foreground",
										children: "CO₂ (kg)"
									})
								]
							}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: allTelemetry.slice(0, 20).map((point) => {
								const date = new Date(point.ts);
								const dateStr = date.toLocaleDateString();
								const timeStr = date.toLocaleTimeString();
								const co2 = (point.power / 1e3 * .25 * GRID_EMISSION_FACTOR_KGCO2_PER_KWH).toFixed(3);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-border/50 hover:bg-secondary/30",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-2 px-3",
											children: point.deviceName || "Unknown"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-2 px-3 text-muted-foreground",
											children: [
												dateStr,
												" ",
												timeStr
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "text-right py-2 px-3",
											children: (point.power / 1e3).toFixed(2)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "text-right py-2 px-3",
											children: co2
										})
									]
								}, point.id);
							}) })]
						})
					}),
					allTelemetry.length > 20 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-xs text-muted-foreground",
						children: [
							"Showing 20 of ",
							allTelemetry.length,
							" readings. Load more to see earlier data."
						]
					})
				]
			})
		]
	});
}
function RecommendationsCard({ totalPotentialSaving, totalPotentialCo2, currency, recommendations }) {
	const [applied, setApplied] = (0, import_react.useState)({});
	const items = recommendations ?? [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "card-surface flex flex-col p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lightbulb, { className: "h-4 w-4 text-warning" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Efficiency recommendations"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: [
					"Identified savings: ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-medium text-foreground",
						children: currency(totalPotentialSaving)
					}),
					" · ",
					totalPotentialCo2,
					" kgCO₂"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-4 flex-1 space-y-3",
				children: items.slice(0, 4).map((r) => {
					const done = applied[r.id];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-lg border border-border bg-secondary/40 p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("rounded-full px-2 py-0.5 text-[10px] font-medium capitalize", priorityStyle[r.priority]),
									children: r.priority
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[11px] text-muted-foreground",
									children: r.category
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm font-medium",
								children: r.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted-foreground",
								children: r.detail
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-xs tabular-nums text-success",
									children: [r.savingTzs > 0 ? `−${currency(r.savingTzs)}` : "Reliability", r.co2SavedKg > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "ml-1.5 text-muted-foreground",
										children: [
											"· −",
											r.co2SavedKg,
											" kgCO₂"
										]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									onClick: () => setApplied((p) => ({
										...p,
										[r.id]: !p[r.id]
									})),
									className: cn("shrink-0 rounded-lg px-2.5 py-1 text-[11px] font-medium transition-colors", done ? "bg-success/12 text-success" : "bg-primary text-primary-foreground hover:opacity-90"),
									children: done ? "Applied" : "Apply"
								})]
							})
						]
					}, r.id);
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/sustainability",
				className: "mt-4 text-xs font-medium text-primary",
				onClick: (e) => e.preventDefault(),
				children: "View all recommendations →"
			})
		]
	});
}
//#endregion
export { SustainabilityPage as component };
