import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as Info, M as BellRing, i as TriangleAlert, k as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as cn, r as useHydranetDashboardData, t as AppShell } from "./dashboard-data-10Pg--aE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/alerts-CwjdYwLD.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var severityMeta = {
	critical: {
		icon: TriangleAlert,
		chip: "bg-destructive/12 text-destructive"
	},
	warning: {
		icon: BellRing,
		chip: "bg-warning/15 text-warning"
	},
	info: {
		icon: Info,
		chip: "bg-secondary text-muted-foreground"
	}
};
function AlertsPage() {
	const { alerts: seed } = useHydranetDashboardData();
	const [rows, setRows] = (0, import_react.useState)(seed);
	const [showAck, setShowAck] = (0, import_react.useState)(true);
	(0, import_react.useEffect)(() => {
		setRows(seed);
	}, [seed]);
	const open = rows.filter((r) => !r.acknowledged);
	const visible = showAck ? rows : open;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Alerts",
		subtitle: `${open.length} open · ${rows.length - open.length} acknowledged`,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			onClick: () => setShowAck((v) => !v),
			className: "hidden h-9 items-center rounded-lg border border-border bg-card px-3 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground sm:flex",
			children: showAck ? "Hide acknowledged" : "Show all"
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "grid gap-4 sm:grid-cols-3",
			children: [
				"critical",
				"warning",
				"info"
			].map((s) => {
				const Icon = severityMeta[s].icon;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "card-surface flex items-center gap-4 p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: cn("grid h-10 w-10 shrink-0 place-items-center rounded-xl", severityMeta[s].chip),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-5 w-5" })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "label-eyebrow",
							children: s
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xl font-semibold tabular-nums",
							children: rows.filter((r) => r.severity === s).length
						})]
					})]
				}, s);
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "card-surface mt-6 overflow-hidden",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "border-b border-border px-5 py-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Event queue"
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "divide-y divide-border",
				children: visible.map((a) => {
					const Icon = severityMeta[a.severity].icon;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex min-w-0 items-start gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg", severityMeta[a.severity].chip),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "truncate text-sm font-medium",
									children: a.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "truncate text-xs text-muted-foreground",
									children: [
										a.device,
										" · ",
										a.time,
										" · ",
										a.id
									]
								})]
							})]
						}), a.acknowledged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "flex shrink-0 items-center gap-1.5 text-xs font-medium text-success",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: "h-4 w-4" }),
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "hidden sm:inline",
									children: "Acknowledged"
								})
							]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							onClick: () => setRows((prev) => prev.map((r) => r.id === a.id ? {
								...r,
								acknowledged: true
							} : r)),
							className: "shrink-0 rounded-lg bg-primary px-3 py-1.5 text-xs font-medium text-primary-foreground transition-opacity hover:opacity-90",
							children: "Acknowledge"
						})]
					}, a.id);
				})
			})]
		})]
	});
}
//#endregion
export { AlertsPage as component };
