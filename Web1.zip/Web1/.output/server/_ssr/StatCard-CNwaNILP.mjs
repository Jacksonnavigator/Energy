import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { I as ArrowDownRight, P as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { n as cn } from "./dashboard-data-10Pg--aE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/StatCard-CNwaNILP.js
var import_jsx_runtime = require_jsx_runtime();
function StatCard({ label, value, unit, delta, icon: Icon, tone = "neutral" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "card-surface p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "label-eyebrow",
					children: label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("grid h-8 w-8 shrink-0 place-items-center rounded-lg", tone === "primary" && "bg-accent text-accent-foreground", tone === "warning" && "bg-warning/15 text-warning", tone === "neutral" && "bg-secondary text-muted-foreground"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 flex items-baseline gap-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-2xl font-semibold tracking-tight tabular-nums sm:text-[1.75rem]",
					children: value
				}), unit && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "text-sm text-muted-foreground",
					children: unit
				})]
			}),
			delta && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: cn("mt-2 flex items-center gap-1 text-xs font-medium", delta.good === false ? "text-destructive" : "text-success"),
				children: [
					delta.direction === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "h-3.5 w-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDownRight, { className: "h-3.5 w-3.5" }),
					delta.value,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-normal text-muted-foreground",
						children: "vs last week"
					})
				]
			})
		]
	});
}
//#endregion
export { StatCard as t };
