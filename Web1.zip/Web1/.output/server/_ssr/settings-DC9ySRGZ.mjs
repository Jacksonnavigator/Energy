import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { r as useHydranetDashboardData, t as AppShell } from "./dashboard-data-10Pg--aE.mjs";
import { t as Switch } from "./switch-D0GlNqi8.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/settings-DC9ySRGZ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Field({ label, defaultValue, suffix, placeholder }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "label-eyebrow",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "mt-2 flex h-10 items-center gap-2 rounded-lg border border-input bg-background px-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				defaultValue,
				placeholder,
				className: "min-w-0 flex-1 bg-transparent text-sm outline-none"
			}), suffix && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "shrink-0 text-xs text-muted-foreground",
				children: suffix
			})]
		})]
	});
}
function ToggleRow({ title, desc, initial }) {
	const [on, setOn] = (0, import_react.useState)(initial);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: title
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-xs text-muted-foreground",
				children: desc
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
			checked: on,
			onCheckedChange: setOn
		})]
	});
}
function SettingsPage() {
	const { platformSettings } = useHydranetDashboardData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Settings",
		subtitle: `Organisation, tariffs, thresholds and notifications · ${platformSettings.timezone}`,
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			className: "h-9 rounded-lg bg-primary px-3 text-xs font-medium text-primary-foreground transition-opacity hover:opacity-90",
			children: "Save changes"
		}),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Organisation"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Organisation name",
								defaultValue: platformSettings.timezone ? "" : "",
								placeholder: "Not configured"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Primary contact",
								defaultValue: "",
								placeholder: "Not configured"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Reporting timezone",
								defaultValue: platformSettings.timezone
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Tariff & thresholds"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-5 space-y-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Unit rate",
								defaultValue: String(platformSettings.tariffPerKwh || 0),
								suffix: "TZS/kWh"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Monthly budget",
								defaultValue: String(platformSettings.maxDailyCost * 30 || 0),
								suffix: "TZS"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Overload warning",
								defaultValue: String(platformSettings.maxPower ? 85 : 0),
								suffix: "% of rated"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Stale telemetry timeout",
								defaultValue: "0",
								suffix: "minutes"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Relay command timeout",
								defaultValue: "0",
								suffix: "seconds"
							})
						]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-4 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Notifications"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 divide-y divide-border",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							title: "Critical fault alerts",
							desc: "Email and SMS the on-call operator immediately",
							initial: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							title: "Threshold warnings",
							desc: "Notify when load or power factor breaches limits",
							initial: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							title: "Weekly digest",
							desc: "Consumption and cost summary every Monday 07:00",
							initial: true
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToggleRow, {
							title: "Relay change confirmations",
							desc: "Send a receipt whenever an asset is switched",
							initial: false
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-4 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Danger zone"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-w-0 text-xs text-muted-foreground",
						children: "Deregistering removes all devices and permanently deletes historical telemetry."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						className: "shrink-0 rounded-lg border border-destructive/40 px-3 py-2 text-xs font-medium text-destructive transition-colors hover:bg-destructive/10",
						children: "Deregister account"
					})]
				})]
			})
		]
	});
}
//#endregion
export { SettingsPage as component };
