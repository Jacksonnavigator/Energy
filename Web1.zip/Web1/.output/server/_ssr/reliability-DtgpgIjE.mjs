import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { C as Info, a as TrendingUp, c as Timer, f as ShieldCheck, i as TriangleAlert, k as CircleCheck } from "../_libs/lucide-react.mjs";
import { n as cn, r as useHydranetDashboardData, t as AppShell } from "./dashboard-data-10Pg--aE.mjs";
import { t as StatCard } from "./StatCard-CNwaNILP.mjs";
import { a as YAxis, f as Cell, l as CartesianGrid, m as Tooltip, o as XAxis, p as ResponsiveContainer, r as BarChart, u as Bar } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/reliability-DtgpgIjE.js
var import_jsx_runtime = require_jsx_runtime();
var tooltipStyle = {
	background: "var(--popover)",
	border: "1px solid var(--border)",
	borderRadius: "0.75rem",
	fontSize: 12,
	color: "var(--popover-foreground)"
};
var severityMeta = {
	critical: {
		icon: TriangleAlert,
		chip: "bg-destructive/12 text-destructive"
	},
	warning: {
		icon: TriangleAlert,
		chip: "bg-warning/15 text-warning"
	},
	info: {
		icon: Info,
		chip: "bg-secondary text-muted-foreground"
	}
};
function ReliabilityPage() {
	const { devices, incidentHistory, safetyStatus, uptimeBySite, allTelemetry } = useHydranetDashboardData();
	const total = Math.max(devices.length, 1);
	const online = devices.filter((device) => device.status === "online").length;
	const uptime = Number((online / total * 100).toFixed(2));
	const slaOk = uptime >= 99.5;
	const avgRecovery = devices.length ? `${Math.max(2, Math.round((total - online) * 3))} min` : "0 min";
	const avgResponse = devices.length ? `${Math.max(1, Math.round((total - online) * 2))}m ${Math.max(0, (total - online) * 20 % 60)}s` : "0m 0s";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AppShell, {
		title: "Reliability & Safety",
		subtitle: `Uptime, SLA, incident response and protection · ${devices.length} devices`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 sm:grid-cols-2 xl:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Fleet uptime",
						value: `${uptime}%`,
						icon: TrendingUp,
						tone: "primary"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "SLA compliance",
						value: slaOk ? "On target" : "At risk",
						icon: ShieldCheck,
						tone: slaOk ? "neutral" : "warning"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Mean time to recover",
						value: avgRecovery,
						icon: Timer
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
						label: "Avg. response",
						value: avgResponse,
						icon: Timer
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 grid gap-4 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5 lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "truncate text-sm font-semibold",
								children: "Uptime by site vs SLA"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "truncate text-xs text-muted-foreground",
								children: "Rolling 30-day availability against contracted SLA"
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "shrink-0 rounded-full bg-secondary px-2.5 py-1 text-[11px] font-medium text-muted-foreground",
							children: "%"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-5 h-64",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: uptimeBySite,
								margin: {
									left: -18,
									right: 4,
									top: 8
								},
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CartesianGrid, {
										stroke: "var(--border)",
										vertical: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "site",
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 10,
											fill: "var(--muted-foreground)"
										},
										interval: 0
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, {
										domain: [97, 100],
										tickLine: false,
										axisLine: false,
										tick: {
											fontSize: 11,
											fill: "var(--muted-foreground)"
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										cursor: { fill: "var(--secondary)" },
										contentStyle: tooltipStyle
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "uptime",
										name: "Uptime",
										radius: [
											6,
											6,
											0,
											0
										],
										children: uptimeBySite.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cell, { fill: s.uptime >= s.sla ? "var(--chart-1)" : "var(--chart-2)" }, s.site))
									})
								]
							})
						})
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "card-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-sm font-semibold",
							children: "Safety & protection"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-4 space-y-3.5",
							children: [
								{
									k: "Relays safely controlled",
									v: safetyStatus.relaySafelyControlled
								},
								{
									k: "Fault protection armed",
									v: safetyStatus.faultProtectionArmed
								},
								{
									k: "Within load envelope",
									v: safetyStatus.overloadProtected
								},
								{
									k: "Active ground faults",
									v: safetyStatus.groundFaults,
									danger: true
								}
							].map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2 text-sm",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CircleCheck, { className: cn("h-4 w-4", s.danger ? "text-destructive" : "text-success") }), s.k]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("text-sm font-semibold tabular-nums", s.danger && s.v > 0 && "text-destructive"),
									children: s.v
								})]
							}, s.k))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 border-t border-border pt-4 text-xs text-muted-foreground",
							children: ["Last safety audit · ", safetyStatus.lastSafetyAudit]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-6 overflow-hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "border-b border-border px-5 py-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-sm font-semibold",
						children: "Incident history"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: "Detection, recovery time and root cause for recent events"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "divide-y divide-border",
					children: incidentHistory.map((i) => {
						const Icon = severityMeta[i.severity].icon;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "grid grid-cols-[minmax(0,1fr)_auto] items-center gap-4 px-5 py-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex min-w-0 items-start gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg", severityMeta[i.severity].chip),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "h-4 w-4" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "min-w-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "truncate text-sm font-medium",
											children: i.title
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "truncate text-xs text-muted-foreground",
											children: [
												i.device,
												" · ",
												i.id,
												" · detected ",
												i.detected
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 truncate text-xs text-muted-foreground",
											children: ["Root cause: ", i.rootCause]
										})
									]
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "shrink-0 text-right",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold tabular-nums",
									children: i.duration
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground capitalize",
									children: i.severity
								})]
							})]
						}, i.id);
					})
				})]
			}),
			allTelemetry.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "card-surface mt-6 p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-sm font-semibold",
					children: "Live reliability telemetry"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-4 overflow-x-auto",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
						className: "w-full text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-b border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left py-2 px-3 font-medium text-muted-foreground",
									children: "Device"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-left py-2 px-3 font-medium text-muted-foreground",
									children: "Date & Time"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
									className: "text-right py-2 px-3 font-medium text-muted-foreground",
									children: "Power (kW)"
								})
							]
						}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: allTelemetry.slice(0, 15).map((point) => {
							const date = new Date(point.ts);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-b border-border/50 hover:bg-secondary/30",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 px-3",
										children: point.deviceName || "Unknown"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-2 px-3 text-muted-foreground",
										children: date.toLocaleString()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "text-right py-2 px-3",
										children: (point.power / 1e3).toFixed(2)
									})
								]
							}, point.id);
						}) })]
					})
				})]
			})
		]
	});
}
//#endregion
export { ReliabilityPage as component };
